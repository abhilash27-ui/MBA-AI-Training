import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  DEFAULT_BUSINESS_PROFILE,
  MONTHLY_SAMPLE_BENCHMARK,
  SAMPLE_ACTIVITIES,
  SAMPLE_LEADS,
  SAMPLE_RECOMMENDATIONS,
} from '../data/sampleData';
import {
  ActivityStatus,
  BusinessProfile,
  CustomerLead,
  LeadSource,
  LeadStatus,
  MarketingActivity,
} from '../types/bizgrow';

const STORAGE_KEYS = {
  LEADS: 'bizgrow_leads_v1',
  ACTIVITIES: 'bizgrow_activities_v1',
  PROFILE: 'bizgrow_profile_v1',
  LOGGED_IN: 'bizgrow_logged_in_v1',
};

function readStorage<T>(key: string, fallback: T): T {
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export function useBizGrowStore() {
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(() =>
    readStorage<boolean>(STORAGE_KEYS.LOGGED_IN, false)
  );
  const [profile, setProfile] = useState<BusinessProfile>(() =>
    readStorage<BusinessProfile>(STORAGE_KEYS.PROFILE, DEFAULT_BUSINESS_PROFILE)
  );
  const [leads, setLeads] = useState<CustomerLead[]>(() =>
    readStorage<CustomerLead[]>(STORAGE_KEYS.LEADS, SAMPLE_LEADS)
  );
  const [activities, setActivities] = useState<MarketingActivity[]>(() =>
    readStorage<MarketingActivity[]>(STORAGE_KEYS.ACTIVITIES, SAMPLE_ACTIVITIES)
  );

  useEffect(() => {
    window.localStorage.setItem(STORAGE_KEYS.LOGGED_IN, JSON.stringify(isLoggedIn));
  }, [isLoggedIn]);

  useEffect(() => {
    window.localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(profile));
  }, [profile]);

  useEffect(() => {
    window.localStorage.setItem(STORAGE_KEYS.LEADS, JSON.stringify(leads));
  }, [leads]);

  useEffect(() => {
    window.localStorage.setItem(STORAGE_KEYS.ACTIVITIES, JSON.stringify(activities));
  }, [activities]);

  const loginWithEmail = useCallback((email: string, businessName?: string) => {
    setProfile((prev) => ({
      ...prev,
      email: email.trim() || 'owner@sharmadigital.in',
      businessName: businessName?.trim() ? businessName.trim() : prev.businessName,
      isDemoUser: false,
    }));
    setIsLoggedIn(true);
  }, []);

  const continueAsDemoUser = useCallback(() => {
    setProfile(DEFAULT_BUSINESS_PROFILE);
    setIsLoggedIn(true);
  }, []);

  const logout = useCallback(() => {
    setIsLoggedIn(false);
  }, []);

  const addLead = useCallback(
    (payload: {
      customerName: string;
      mobileNumber: string;
      email: string;
      businessRequirement: string;
      source: LeadSource;
      status: LeadStatus;
      followUpDate: string;
    }) => {
      const newLead: CustomerLead = {
        id: `lead_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
        customerName: payload.customerName.trim(),
        mobileNumber: payload.mobileNumber.trim(),
        email: payload.email.trim(),
        businessRequirement: payload.businessRequirement.trim(),
        source: payload.source,
        status: payload.status,
        followUpDate: payload.followUpDate,
        isSample: false,
      };
      setLeads((prev) => [newLead, ...prev]);
    },
    []
  );

  const updateLeadStatus = useCallback((leadId: string, status: LeadStatus) => {
    setLeads((prev) => prev.map((lead) => (lead.id === leadId ? { ...lead, status } : lead)));
  }, []);

  const addMarketingActivity = useCallback(
    (payload: {
      name: string;
      description: string;
      status: ActivityStatus;
      budgetInr: number;
      targetAudience: string;
      expectedOutcome: string;
    }) => {
      const newActivity: MarketingActivity = {
        id: `act_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
        name: payload.name.trim(),
        description: payload.description.trim(),
        status: payload.status,
        budgetInr: payload.budgetInr,
        targetAudience: payload.targetAudience.trim() || 'Local Nagpur customers',
        expectedOutcome: payload.expectedOutcome.trim() || 'Increase local enquiries',
        isSample: false,
      };
      setActivities((prev) => [newActivity, ...prev]);
    },
    []
  );

  const updateActivityStatus = useCallback((activityId: string, status: ActivityStatus) => {
    setActivities((prev) =>
      prev.map((act) => (act.id === activityId ? { ...act, status } : act))
    );
  }, []);

  const resetDemoData = useCallback(() => {
    setLeads(SAMPLE_LEADS);
    setActivities(SAMPLE_ACTIVITIES);
    setProfile(DEFAULT_BUSINESS_PROFILE);
  }, []);

  const metrics = useMemo(() => {
    const newCount = leads.filter((l) => l.status === 'New').length;
    const contactedCount = leads.filter((l) => l.status === 'Contacted').length;
    const interestedCount = leads.filter((l) => l.status === 'Interested').length;
    const convertedCount = leads.filter((l) => l.status === 'Converted').length;
    const lostCount = leads.filter((l) => l.status === 'Lost').length;

    // Business Formula: Total Leads = New + Contacted + Interested + Converted + Lost
    const totalLeads = newCount + contactedCount + interestedCount + convertedCount + lostCount;

    // Business Formula: Conversion Rate = (Converted Leads / Total Leads) * 100
    const conversionRatePercent = totalLeads > 0 ? (convertedCount / totalLeads) * 100 : 0;

    // Business Formula: Total Expenditure = Sum of all marketing activity budgets
    const totalMarketingExpenditureInr = activities.reduce(
      (sum, item) => sum + item.budgetInr,
      0
    );

    // Estimated revenue scales when additional converted leads are added beyond initial 3 sample converted
    const extraConverted = Math.max(0, convertedCount - 3);
    const estimatedRevenueInr =
      MONTHLY_SAMPLE_BENCHMARK.estimatedRevenueInr + extraConverted * 12500;

    return {
      totalLeads,
      newCount,
      contactedCount,
      interestedCount,
      convertedCount,
      lostCount,
      conversionRatePercent,
      totalMarketingExpenditureInr,
      estimatedRevenueInr,
      userAddedLeadsCount: leads.filter((l) => !l.isSample).length,
      sampleLeadsCount: leads.filter((l) => l.isSample).length,
      userAddedActivitiesCount: activities.filter((a) => !a.isSample).length,
    };
  }, [leads, activities]);

  return {
    isLoggedIn,
    profile,
    leads,
    activities,
    recommendations: SAMPLE_RECOMMENDATIONS,
    sampleBenchmark: MONTHLY_SAMPLE_BENCHMARK,
    metrics,
    loginWithEmail,
    continueAsDemoUser,
    logout,
    addLead,
    updateLeadStatus,
    addMarketingActivity,
    updateActivityStatus,
    resetDemoData,
  };
}
