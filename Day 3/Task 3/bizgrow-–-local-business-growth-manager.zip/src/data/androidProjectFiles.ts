import readmeMd from '../../android/README.md?raw';
import settingsGradle from '../../android/settings.gradle.kts?raw';
import rootBuildGradle from '../../android/build.gradle.kts?raw';
import gradleProperties from '../../android/gradle.properties?raw';
import appBuildGradle from '../../android/app/build.gradle.kts?raw';
import androidManifest from '../../android/app/src/main/AndroidManifest.xml?raw';
import stringsXml from '../../android/app/src/main/res/values/strings.xml?raw';
import themesXml from '../../android/app/src/main/res/values/themes.xml?raw';
import mainActivityKt from '../../android/app/src/main/java/com/bizgrow/app/MainActivity.kt?raw';
import modelsKt from '../../android/app/src/main/java/com/bizgrow/app/model/BizGrowModels.kt?raw';
import sampleDataKt from '../../android/app/src/main/java/com/bizgrow/app/data/SampleData.kt?raw';
import localStoreKt from '../../android/app/src/main/java/com/bizgrow/app/data/BizGrowLocalStore.kt?raw';
import viewModelKt from '../../android/app/src/main/java/com/bizgrow/app/viewmodel/BizGrowViewModel.kt?raw';
import themeKt from '../../android/app/src/main/java/com/bizgrow/app/ui/theme/Theme.kt?raw';
import componentsKt from '../../android/app/src/main/java/com/bizgrow/app/ui/components/BizGrowComponents.kt?raw';
import navGraphKt from '../../android/app/src/main/java/com/bizgrow/app/ui/navigation/BizGrowNavGraph.kt?raw';
import welcomeScreenKt from '../../android/app/src/main/java/com/bizgrow/app/ui/screens/WelcomeLoginScreen.kt?raw';
import dashboardScreenKt from '../../android/app/src/main/java/com/bizgrow/app/ui/screens/DashboardScreen.kt?raw';
import leadsScreenKt from '../../android/app/src/main/java/com/bizgrow/app/ui/screens/LeadsScreen.kt?raw';
import marketingScreenKt from '../../android/app/src/main/java/com/bizgrow/app/ui/screens/MarketingScreen.kt?raw';
import reportsScreenKt from '../../android/app/src/main/java/com/bizgrow/app/ui/screens/ReportsScreen.kt?raw';
import recommendationsScreenKt from '../../android/app/src/main/java/com/bizgrow/app/ui/screens/RecommendationsScreen.kt?raw';

export interface AndroidSourceFile {
  path: string;
  category: 'Kotlin Screens' | 'MVVM & Data' | 'Theme & Navigation' | 'Gradle & Manifest';
  content: string;
}

export const ANDROID_PROJECT_FILES: AndroidSourceFile[] = [
  {
    path: 'android/app/src/main/java/com/bizgrow/app/MainActivity.kt',
    category: 'Theme & Navigation',
    content: mainActivityKt,
  },
  {
    path: 'android/app/src/main/java/com/bizgrow/app/ui/navigation/BizGrowNavGraph.kt',
    category: 'Theme & Navigation',
    content: navGraphKt,
  },
  {
    path: 'android/app/src/main/java/com/bizgrow/app/ui/theme/Theme.kt',
    category: 'Theme & Navigation',
    content: themeKt,
  },
  {
    path: 'android/app/src/main/java/com/bizgrow/app/ui/components/BizGrowComponents.kt',
    category: 'Theme & Navigation',
    content: componentsKt,
  },
  {
    path: 'android/app/src/main/java/com/bizgrow/app/ui/screens/WelcomeLoginScreen.kt',
    category: 'Kotlin Screens',
    content: welcomeScreenKt,
  },
  {
    path: 'android/app/src/main/java/com/bizgrow/app/ui/screens/DashboardScreen.kt',
    category: 'Kotlin Screens',
    content: dashboardScreenKt,
  },
  {
    path: 'android/app/src/main/java/com/bizgrow/app/ui/screens/LeadsScreen.kt',
    category: 'Kotlin Screens',
    content: leadsScreenKt,
  },
  {
    path: 'android/app/src/main/java/com/bizgrow/app/ui/screens/MarketingScreen.kt',
    category: 'Kotlin Screens',
    content: marketingScreenKt,
  },
  {
    path: 'android/app/src/main/java/com/bizgrow/app/ui/screens/ReportsScreen.kt',
    category: 'Kotlin Screens',
    content: reportsScreenKt,
  },
  {
    path: 'android/app/src/main/java/com/bizgrow/app/ui/screens/RecommendationsScreen.kt',
    category: 'Kotlin Screens',
    content: recommendationsScreenKt,
  },
  {
    path: 'android/app/src/main/java/com/bizgrow/app/viewmodel/BizGrowViewModel.kt',
    category: 'MVVM & Data',
    content: viewModelKt,
  },
  {
    path: 'android/app/src/main/java/com/bizgrow/app/model/BizGrowModels.kt',
    category: 'MVVM & Data',
    content: modelsKt,
  },
  {
    path: 'android/app/src/main/java/com/bizgrow/app/data/BizGrowLocalStore.kt',
    category: 'MVVM & Data',
    content: localStoreKt,
  },
  {
    path: 'android/app/src/main/java/com/bizgrow/app/data/SampleData.kt',
    category: 'MVVM & Data',
    content: sampleDataKt,
  },
  {
    path: 'android/app/build.gradle.kts',
    category: 'Gradle & Manifest',
    content: appBuildGradle,
  },
  {
    path: 'android/build.gradle.kts',
    category: 'Gradle & Manifest',
    content: rootBuildGradle,
  },
  {
    path: 'android/settings.gradle.kts',
    category: 'Gradle & Manifest',
    content: settingsGradle,
  },
  {
    path: 'android/gradle.properties',
    category: 'Gradle & Manifest',
    content: gradleProperties,
  },
  {
    path: 'android/app/src/main/AndroidManifest.xml',
    category: 'Gradle & Manifest',
    content: androidManifest,
  },
  {
    path: 'android/app/src/main/res/values/strings.xml',
    category: 'Gradle & Manifest',
    content: stringsXml,
  },
  {
    path: 'android/app/src/main/res/values/themes.xml',
    category: 'Gradle & Manifest',
    content: themesXml,
  },
  {
    path: 'android/README.md',
    category: 'Gradle & Manifest',
    content: readmeMd,
  },
];
