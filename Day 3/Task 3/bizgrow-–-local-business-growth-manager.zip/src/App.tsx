import React, { useState } from 'react';
import {
  BarChart3,
  Code2,
  LayoutDashboard,
  Lightbulb,
  LogOut,
  Megaphone,
  Monitor,
  Smartphone,
  Users,
} from 'lucide-react';
import { AndroidStudioModal } from './components/AndroidStudioModal';
import { ScreenDashboard } from './components/ScreenDashboard';
import { ScreenLeads } from './components/ScreenLeads';
import { ScreenMarketing } from './components/ScreenMarketing';
import { ScreenRecommendations } from './components/ScreenRecommendations';
import { ScreenReports } from './components/ScreenReports';
import { ScreenWelcomeLogin } from './components/ScreenWelcomeLogin';
import { useBizGrowStore } from './hooks/useBizGrowStore';
import { ScreenRoute } from './types/bizgrow';

interface NavTab {
  route: Exclude<ScreenRoute, 'welcome'>;
  label: string;
  shortLabel: string;
  Icon: React.FC<{ className?: string }>;
}

const NAV_TABS: NavTab[] = [
  { route: 'dashboard', label: 'Dashboard', shortLabel: 'Dashboard', Icon: LayoutDashboard },
  { route: 'leads', label: 'Manage Leads', shortLabel: 'Leads', Icon: Users },
  { route: 'marketing', label: 'Marketing', shortLabel: 'Marketing', Icon: Megaphone },
  { route: 'reports', label: 'Reports', shortLabel: 'Reports', Icon: BarChart3 },
  { route: 'recommendations', label: 'Recommendations', shortLabel: 'Advice', Icon: Lightbulb },
];

export default function App() {
  const {
    isLoggedIn,
    profile,
    leads,
    activities,
    recommendations,
    sampleBenchmark,
    metrics,
    loginWithEmail,
    continueAsDemoUser,
    logout,
    addLead,
    updateLeadStatus,
    addMarketingActivity,
    updateActivityStatus,
    resetDemoData,
  } = useBizGrowStore();

  const [activeScreen, setActiveScreen] = useState<ScreenRoute>(() =>
    isLoggedIn ? 'dashboard' : 'welcome'
  );
  const [viewMode, setViewMode] = useState<'desktop' | 'phone'>('desktop');
  const [isAndroidModalOpen, setIsAndroidModalOpen] = useState(false);

  const handleLogin = (email: string, businessName?: string) => {
    loginWithEmail(email, businessName);
    setActiveScreen('dashboard');
  };

  const handleDemoUser = () => {
    continueAsDemoUser();
    setActiveScreen('dashboard');
  };

  const handleLogout = () => {
    logout();
    setActiveScreen('welcome');
  };

  const currentTab: Exclude<ScreenRoute, 'welcome'> =
    activeScreen === 'welcome' ? 'dashboard' : activeScreen;

  const renderActiveContent = () => {
    switch (currentTab) {
      case 'dashboard':
        return (
          <ScreenDashboard
            profile={profile}
            leads={leads}
            activities={activities}
            sampleBenchmark={sampleBenchmark}
            metrics={metrics}
            onNavigate={(route) => setActiveScreen(route)}
            onResetDemo={resetDemoData}
          />
        );
      case 'leads':
        return (
          <ScreenLeads
            leads={leads}
            onAddLead={addLead}
            onUpdateLeadStatus={updateLeadStatus}
          />
        );
      case 'marketing':
        return (
          <ScreenMarketing
            activities={activities}
            totalExpenditureInr={metrics.totalMarketingExpenditureInr}
            onAddActivity={addMarketingActivity}
            onUpdateActivityStatus={updateActivityStatus}
          />
        );
      case 'reports':
        return (
          <ScreenReports
            leads={leads}
            sampleBenchmark={sampleBenchmark}
            metrics={metrics}
          />
        );
      case 'recommendations':
        return <ScreenRecommendations recommendations={recommendations} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      {/* Top Bar Contract: Brand wordmark — Nav links — 1 Primary Action */}
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-8">
          <button
            type="button"
            onClick={() => setActiveScreen(isLoggedIn ? 'dashboard' : 'welcome')}
            className="text-lg font-extrabold tracking-tight text-[#0B192C] whitespace-nowrap shrink-0 cursor-pointer"
          >
            BizGrow
          </button>

          {isLoggedIn && activeScreen !== 'welcome' ? (
            <nav
              aria-label="Primary navigation"
              className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600"
            >
              {NAV_TABS.map(({ route, label }) => {
                const isActive = currentTab === route;
                return (
                  <button
                    key={route}
                    type="button"
                    onClick={() => setActiveScreen(route)}
                    className={`py-1 whitespace-nowrap shrink-0 transition-colors border-b-2 cursor-pointer ${
                      isActive
                        ? 'text-[#0B192C] font-semibold border-teal-600'
                        : 'border-transparent hover:text-slate-900'
                    }`}
                  >
                    {label}
                  </button>
                );
              })}
            </nav>
          ) : (
            <div className="hidden md:block" />
          )}

          <button
            type="button"
            onClick={() => setIsAndroidModalOpen(true)}
            className="min-h-[38px] px-3.5 py-1.5 bg-[#0B192C] hover:bg-[#132948] text-white text-xs font-semibold rounded-lg transition-colors inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Code2 className="w-3.5 h-3.5 text-teal-400" />
            <span>Android Kotlin ZIP</span>
          </button>
        </div>
      </header>

      {/* Workspace Utility Strip (below top bar) */}
      {isLoggedIn && activeScreen !== 'welcome' && (
        <div className="bg-slate-100/80 border-b border-slate-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2 flex flex-wrap items-center justify-between gap-3">
            <div className="text-xs text-slate-600">
              <span className="font-semibold text-slate-900">{profile.businessName}</span> ·{' '}
              {profile.location}
            </div>

            <div className="flex items-center gap-2">
              <div className="hidden lg:inline-flex items-center p-0.5 bg-white border border-slate-200 rounded-lg">
                <button
                  type="button"
                  onClick={() => setViewMode('desktop')}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md inline-flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                    viewMode === 'desktop'
                      ? 'bg-[#0B192C] text-white'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Monitor className="w-3.5 h-3.5" />
                  <span>Full Workspace</span>
                </button>
                <button
                  type="button"
                  onClick={() => setViewMode('phone')}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md inline-flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                    viewMode === 'phone'
                      ? 'bg-[#0B192C] text-white'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Smartphone className="w-3.5 h-3.5" />
                  <span>Android Frame (390px)</span>
                </button>
              </div>

              <button
                type="button"
                onClick={handleLogout}
                className="min-h-[34px] px-3 py-1 bg-white border border-slate-200 hover:border-slate-300 text-xs font-medium text-slate-700 rounded-lg inline-flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      {!isLoggedIn || activeScreen === 'welcome' ? (
        <main className="flex-1">
          <ScreenWelcomeLogin onLogin={handleLogin} onContinueAsDemo={handleDemoUser} />
        </main>
      ) : viewMode === 'phone' ? (
        <main className="flex-1 py-6 px-4 flex justify-center items-start bg-slate-200/60">
          <div className="w-[390px] h-[780px] bg-slate-50 rounded-[36px] border-[8px] border-[#0B192C] shadow-2xl flex flex-col overflow-hidden">
            {/* Android Material 3 TopAppBar */}
            <div className="bg-[#0B192C] text-white px-4 py-3 flex items-center justify-between shrink-0">
              <div className="min-w-0">
                <div className="text-sm font-bold truncate">
                  BizGrow · {profile.businessName}
                </div>
              </div>
              <button
                type="button"
                onClick={handleLogout}
                aria-label="Sign Out"
                className="p-1.5 text-slate-300 hover:text-white cursor-pointer"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>

            {/* Scrollable Mobile Viewport */}
            <div className="flex-1 overflow-y-auto p-4">{renderActiveContent()}</div>

            {/* Android Material 3 Bottom NavigationBar */}
            <nav
              aria-label="Android bottom navigation"
              className="bg-white border-t border-slate-200 grid grid-cols-5 h-16 shrink-0"
            >
              {NAV_TABS.map(({ route, shortLabel, Icon }) => {
                const isActive = currentTab === route;
                return (
                  <button
                    key={route}
                    type="button"
                    onClick={() => setActiveScreen(route)}
                    className={`flex flex-col items-center justify-center gap-0.5 text-[10px] font-semibold cursor-pointer ${
                      isActive ? 'text-teal-700' : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    <span
                      className={`px-3 py-1 rounded-full ${
                        isActive ? 'bg-teal-100 text-teal-800' : ''
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                    </span>
                    <span>{shortLabel}</span>
                  </button>
                );
              })}
            </nav>
          </div>
        </main>
      ) : (
        <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 pb-24 md:pb-8">
          {renderActiveContent()}
        </main>
      )}

      {/* Mobile Bottom Navigation Bar (when viewing on actual mobile viewport) */}
      {isLoggedIn && activeScreen !== 'welcome' && viewMode !== 'phone' && (
        <nav
          aria-label="Mobile navigation"
          className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 grid grid-cols-5 h-16"
        >
          {NAV_TABS.map(({ route, shortLabel, Icon }) => {
            const isActive = currentTab === route;
            return (
              <button
                key={route}
                type="button"
                onClick={() => setActiveScreen(route)}
                className={`flex flex-col items-center justify-center gap-1 text-[10px] font-semibold cursor-pointer ${
                  isActive ? 'text-teal-700' : 'text-slate-500'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span>{shortLabel}</span>
              </button>
            );
          })}
        </nav>
      )}

      <AndroidStudioModal
        isOpen={isAndroidModalOpen}
        onClose={() => setIsAndroidModalOpen(false)}
      />
    </div>
  );
}
