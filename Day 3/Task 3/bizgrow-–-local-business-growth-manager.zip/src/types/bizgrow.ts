export type LeadSource = 'Google' | 'Instagram' | 'Facebook' | 'Referral' | 'Walk-in';

export type LeadStatus = 'New' | 'Contacted' | 'Interested' | 'Converted' | 'Lost';

export type ActivityStatus = 'Pending' | 'In Progress' | 'Completed';

export type PriorityLevel = 'High' | 'Medium' | 'Low';

export type ScreenRoute =
  | 'welcome'
  | 'dashboard'
  | 'leads'
  | 'marketing'
  | 'reports'
  | 'recommendations';

export interface CustomerLead {
  id: string;
  customerName: string;
  mobileNumber: string;
  email: string;
  businessRequirement: string;
  source: LeadSource;
  status: LeadStatus;
  followUpDate: string;
  isSample: boolean;
}

export interface MarketingActivity {
  id: string;
  name: string;
  description: string;
  status: ActivityStatus;
  budgetInr: number;
  targetAudience: string;
  expectedOutcome: string;
  isSample: boolean;
}

export interface BusinessRecommendation {
  id: string;
  title: string;
  explanation: string;
  priority: PriorityLevel;
  suggestedAction: string;
  expectedBenefit: string;
  isSample: boolean;
}

export interface BusinessProfile {
  businessName: string;
  category: string;
  location: string;
  ownerName: string;
  email: string;
  isDemoUser: boolean;
}

export interface MonthlySampleBenchmark {
  totalEnquiries: number;
  newLeads: number;
  convertedCustomers: number;
  conversionRatePercent: number;
  marketingBudgetInr: number;
  estimatedRevenueInr: number;
  channelBreakdown: {
    channel: string;
    enquiries: number;
  }[];
}
