import React, { useMemo, useState } from 'react';
import { Plus, Search, X } from 'lucide-react';
import { CustomerLead, LeadSource, LeadStatus } from '../types/bizgrow';

interface ScreenLeadsProps {
  leads: CustomerLead[];
  onAddLead: (payload: {
    customerName: string;
    mobileNumber: string;
    email: string;
    businessRequirement: string;
    source: LeadSource;
    status: LeadStatus;
    followUpDate: string;
  }) => void;
  onUpdateLeadStatus: (leadId: string, status: LeadStatus) => void;
}

const LEAD_SOURCES: LeadSource[] = ['Google', 'Instagram', 'Facebook', 'Referral', 'Walk-in'];
const LEAD_STATUSES: LeadStatus[] = ['New', 'Contacted', 'Interested', 'Converted', 'Lost'];

const STATUS_STYLE: Record<LeadStatus, string> = {
  New: 'text-slate-900 border-slate-300 bg-slate-50',
  Contacted: 'text-sky-800 border-sky-200 bg-sky-50',
  Interested: 'text-amber-800 border-amber-200 bg-amber-50',
  Converted: 'text-emerald-800 border-emerald-200 bg-emerald-50',
  Lost: 'text-red-700 border-red-200 bg-red-50',
};

export const ScreenLeads: React.FC<ScreenLeadsProps> = ({
  leads,
  onAddLead,
  onUpdateLeadStatus,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | LeadStatus>('All');
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Form state
  const [customerName, setCustomerName] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [email, setEmail] = useState('');
  const [businessRequirement, setBusinessRequirement] = useState('');
  const [source, setSource] = useState<LeadSource>('Google');
  const [status, setStatus] = useState<LeadStatus>('New');
  const [followUpDate, setFollowUpDate] = useState('2026-11-30');
  const [formError, setFormError] = useState<string | null>(null);

  const filteredLeads = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return leads.filter((lead) => {
      const matchesStatus = statusFilter === 'All' || lead.status === statusFilter;
      const matchesQuery =
        !q ||
        lead.customerName.toLowerCase().includes(q) ||
        lead.mobileNumber.toLowerCase().includes(q) ||
        lead.email.toLowerCase().includes(q) ||
        lead.businessRequirement.toLowerCase().includes(q) ||
        lead.source.toLowerCase().includes(q);
      return matchesStatus && matchesQuery;
    });
  }, [leads, searchQuery, statusFilter]);

  const handleSaveLead = (e: React.FormEvent) => {
    e.preventDefault();
    const digits = mobileNumber.replace(/\D/g, '');
    if (!customerName.trim()) {
      setFormError('Customer name is required.');
      return;
    }
    if (digits.length < 10) {
      setFormError('Please enter a valid 10-digit mobile number.');
      return;
    }
    if (!businessRequirement.trim()) {
      setFormError('Please describe the customer requirement.');
      return;
    }

    onAddLead({
      customerName,
      mobileNumber: digits,
      email,
      businessRequirement,
      source,
      status,
      followUpDate,
    });

    setCustomerName('');
    setMobileNumber('');
    setEmail('');
    setBusinessRequirement('');
    setSource('Google');
    setStatus('New');
    setFollowUpDate('2026-11-30');
    setFormError(null);
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-5">
      {/* Header Row */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Customer Lead Management</h2>
          <p className="text-xs sm:text-sm text-slate-500 tabular-nums">
            Total Leads: {leads.length} · Converted:{' '}
            {leads.filter((l) => l.status === 'Converted').length} · User Added:{' '}
            {leads.filter((l) => !l.isSample).length}
          </p>
        </div>

        <button
          type="button"
          onClick={() => setIsModalOpen(true)}
          className="min-h-[44px] px-4 py-2.5 bg-teal-600 hover:bg-teal-700 text-white text-sm font-semibold rounded-xl transition-colors inline-flex items-center justify-center gap-2 whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Lead</span>
        </button>
      </div>

      {/* Search & Status Filter */}
      <div className="space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by customer name, mobile number, source, or requirement..."
            className="w-full min-h-[44px] pl-10 pr-4 py-2.5 text-sm bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-600/30 focus:border-teal-600"
          />
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          {(['All', ...LEAD_STATUSES] as const).map((tab) => {
            const count =
              tab === 'All' ? leads.length : leads.filter((l) => l.status === tab).length;
            const active = statusFilter === tab;
            return (
              <button
                key={tab}
                type="button"
                onClick={() => setStatusFilter(tab)}
                className={`min-h-[38px] px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  active
                    ? 'bg-[#0B192C] text-white'
                    : 'bg-white border border-slate-200 text-slate-600 hover:text-slate-900'
                }`}
              >
                {tab} ({count})
              </button>
            );
          })}
        </div>
      </div>

      {/* Lead Records */}
      {filteredLeads.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-2xl p-8 text-center">
          <div className="text-base font-semibold text-slate-900">No matching customer leads</div>
          <p className="mt-1 text-sm text-slate-500">
            Adjust your search filter or add a new customer enquiry to start tracking conversions.
          </p>
          <button
            type="button"
            onClick={() => setIsModalOpen(true)}
            className="mt-4 min-h-[44px] px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white text-sm font-semibold rounded-xl cursor-pointer"
          >
            Add First Lead
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {filteredLeads.map((lead) => (
            <div
              key={lead.id}
              className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 flex flex-col justify-between gap-3"
            >
              <div>
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <h3 className="text-base font-bold text-slate-900 truncate">
                      {lead.customerName}
                    </h3>
                    <div className="text-xs text-slate-500 mt-0.5 font-mono-tabular">
                      {lead.mobileNumber} {lead.email ? `· ${lead.email}` : ''}
                    </div>
                  </div>
                  <span
                    className={`text-xs font-semibold whitespace-nowrap shrink-0 ${
                      lead.isSample ? 'text-slate-400' : 'text-teal-700'
                    }`}
                  >
                    {lead.isSample ? 'Sample Data' : 'User Added'}
                  </span>
                </div>

                <p className="mt-2.5 text-sm text-slate-700 leading-snug">
                  {lead.businessRequirement}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-3">
                <div className="text-xs text-slate-500">
                  <span className="font-medium text-slate-700">{lead.source}</span> · Follow-up{' '}
                  <span className="font-mono-tabular">{lead.followUpDate}</span>
                </div>

                <select
                  aria-label={`Update status for ${lead.customerName}`}
                  value={lead.status}
                  onChange={(e) => onUpdateLeadStatus(lead.id, e.target.value as LeadStatus)}
                  className={`min-h-[36px] px-2.5 py-1 text-xs font-semibold border rounded-lg cursor-pointer focus:outline-none focus:ring-2 focus:ring-teal-600/30 ${
                    STATUS_STYLE[lead.status]
                  }`}
                >
                  {LEAD_STATUSES.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add New Lead Modal */}
      {isModalOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="add-lead-title"
          className="fixed inset-0 z-50 bg-slate-950/50 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4"
        >
          <div className="bg-white w-full sm:max-w-lg rounded-t-3xl sm:rounded-2xl border border-slate-200 p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 id="add-lead-title" className="text-lg font-bold text-slate-900">
                Add New Customer Lead
              </h3>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 cursor-pointer"
                aria-label="Close modal"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveLead} className="space-y-3.5">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Customer Name *
                </label>
                <input
                  type="text"
                  value={customerName}
                  onChange={(e) => {
                    setCustomerName(e.target.value);
                    setFormError(null);
                  }}
                  placeholder="e.g. Amit Kulkarni"
                  className="w-full min-h-[44px] px-3.5 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-600/30 focus:border-teal-600"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Mobile Number *
                  </label>
                  <input
                    type="tel"
                    value={mobileNumber}
                    onChange={(e) => {
                      setMobileNumber(e.target.value);
                      setFormError(null);
                    }}
                    placeholder="9823012345"
                    className="w-full min-h-[44px] px-3.5 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-600/30 focus:border-teal-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="amit@business.in"
                    className="w-full min-h-[44px] px-3.5 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-600/30 focus:border-teal-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Business Requirement *
                </label>
                <textarea
                  rows={2}
                  value={businessRequirement}
                  onChange={(e) => {
                    setBusinessRequirement(e.target.value);
                    setFormError(null);
                  }}
                  placeholder="Google Business Profile setup, Instagram reels, website..."
                  className="w-full px-3.5 py-2.5 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-600/30 focus:border-teal-600"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Lead Source
                  </label>
                  <select
                    value={source}
                    onChange={(e) => setSource(e.target.value as LeadSource)}
                    className="w-full min-h-[44px] px-3 py-2 text-sm border border-slate-200 rounded-xl bg-white"
                  >
                    {LEAD_SOURCES.map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Lead Status
                  </label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as LeadStatus)}
                    className="w-full min-h-[44px] px-3 py-2 text-sm border border-slate-200 rounded-xl bg-white"
                  >
                    {LEAD_STATUSES.map((st) => (
                      <option key={st} value={st}>
                        {st}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Follow-up Date
                  </label>
                  <input
                    type="date"
                    value={followUpDate}
                    onChange={(e) => setFollowUpDate(e.target.value)}
                    className="w-full min-h-[44px] px-3 py-2 text-sm border border-slate-200 rounded-xl bg-white"
                  />
                </div>
              </div>

              {formError && (
                <div className="text-xs font-medium text-red-600 bg-red-50 border border-red-200 rounded-xl px-3.5 py-2.5">
                  {formError}
                </div>
              )}

              <div className="pt-2 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="min-h-[44px] px-4 py-2 text-sm font-medium text-slate-600 hover:text-slate-900 rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="min-h-[44px] px-5 py-2 bg-teal-600 hover:bg-teal-700 text-white text-sm font-semibold rounded-xl cursor-pointer"
                >
                  Save Lead
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
