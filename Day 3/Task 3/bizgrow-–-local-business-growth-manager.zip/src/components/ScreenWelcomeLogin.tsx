import React, { useState } from 'react';
import { ArrowRight, Lock, Mail, Store, UserCheck } from 'lucide-react';

interface ScreenWelcomeLoginProps {
  onLogin: (email: string, businessName?: string) => void;
  onContinueAsDemo: () => void;
}

export const ScreenWelcomeLogin: React.FC<ScreenWelcomeLoginProps> = ({
  onLogin,
  onContinueAsDemo,
}) => {
  const [isRegisterMode, setIsRegisterMode] = useState(false);
  const [businessName, setBusinessName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !email.includes('@')) {
      setError('Please enter a valid business email address.');
      return;
    }
    if (password.length < 4) {
      setError('Password must be at least 4 characters.');
      return;
    }
    if (isRegisterMode && !businessName.trim()) {
      setError('Please enter your business name.');
      return;
    }
    setError(null);
    onLogin(email, isRegisterMode ? businessName : undefined);
  };

  return (
    <div className="min-h-full flex items-center justify-center p-5 sm:p-8 bg-slate-50">
      <div className="w-full max-w-4xl grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
        {/* Left Brand Story Panel */}
        <div className="lg:col-span-6 bg-[#0B192C] text-white rounded-3xl p-7 sm:p-9 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-3.5">
              <img
                src="/src/assets/images/bizgrow_logo_mark_1795414694850.jpg"
                alt="BizGrow Emblem"
                referrerPolicy="no-referrer"
                className="w-12 h-12 rounded-2xl object-cover shrink-0 border border-white/15"
              />
              <div>
                <h1 className="text-2xl font-bold tracking-tight text-white">BizGrow</h1>
                <p className="text-xs text-teal-300 font-medium">Local Business Growth Manager</p>
              </div>
            </div>

            <h2 className="mt-8 text-3xl sm:text-4xl font-bold tracking-tight text-balance leading-tight">
              Grow Your Local Business Smarter.
            </h2>

            <p className="mt-4 text-sm sm:text-base text-slate-300 leading-relaxed">
              Manage customer enquiries, track lead conversions, monitor digital marketing budgets in ₹,
              and improve Google local visibility from one streamlined Android-ready workspace.
            </p>
          </div>

          <div className="mt-8 pt-6 border-t border-white/10 space-y-2 text-xs text-slate-300">
            <div className="font-medium text-white">Preloaded Demo Business Profile</div>
            <div>Sharma Digital Services · Local Digital Marketing Agency</div>
            <div>Nagpur, Maharashtra, India · Monthly Budget ₹15,000</div>
          </div>
        </div>

        {/* Right Sign In / Register Panel */}
        <div className="lg:col-span-6 bg-white border border-slate-200 rounded-3xl p-7 sm:p-9 flex flex-col justify-center">
          <div>
            <h3 className="text-xl font-bold text-slate-900">
              {isRegisterMode ? 'Register Your Business' : 'Sign in to Your Workspace'}
            </h3>
            <p className="mt-1 text-sm text-slate-500">
              {isRegisterMode
                ? 'Set up a local business profile stored on this device.'
                : 'Access your leads, marketing campaigns, and growth analytics.'}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="mt-6 space-y-4">
            {isRegisterMode && (
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1.5">
                  Business Name
                </label>
                <div className="relative">
                  <Store className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={businessName}
                    onChange={(e) => {
                      setBusinessName(e.target.value);
                      setError(null);
                    }}
                    placeholder="e.g. Sharma Digital Services"
                    className="w-full min-h-[44px] pl-10 pr-3.5 py-2.5 text-sm bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-600/30 focus:border-teal-600"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">
                Email Address
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    setError(null);
                  }}
                  placeholder="owner@sharmadigital.in"
                  className="w-full min-h-[44px] pl-10 pr-3.5 py-2.5 text-sm bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-600/30 focus:border-teal-600"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">
                Password
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    setError(null);
                  }}
                  placeholder="Enter password"
                  className="w-full min-h-[44px] pl-10 pr-3.5 py-2.5 text-sm bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-600/30 focus:border-teal-600"
                />
              </div>
            </div>

            {error && (
              <div className="text-xs font-medium text-red-600 bg-red-50 border border-red-200 rounded-xl px-3.5 py-2.5">
                {error}
              </div>
            )}

            <button
              type="submit"
              className="w-full min-h-[46px] px-5 py-2.5 bg-[#0B192C] hover:bg-[#132948] text-white text-sm font-semibold rounded-xl transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>{isRegisterMode ? 'Register & Open Dashboard' : 'Login'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          <div className="mt-3">
            <button
              type="button"
              onClick={onContinueAsDemo}
              className="w-full min-h-[46px] px-5 py-2.5 bg-teal-600 hover:bg-teal-700 text-white text-sm font-semibold rounded-xl transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              <UserCheck className="w-4 h-4" />
              <span>Continue as Demo User</span>
            </button>
          </div>

          <div className="mt-5 text-center">
            <button
              type="button"
              onClick={() => {
                setIsRegisterMode((prev) => !prev);
                setError(null);
              }}
              className="text-xs font-semibold text-slate-600 hover:text-teal-700 transition-colors min-h-[40px] px-3 cursor-pointer"
            >
              {isRegisterMode
                ? 'Already have an account? Sign in instead'
                : 'New business owner? Register an account'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
