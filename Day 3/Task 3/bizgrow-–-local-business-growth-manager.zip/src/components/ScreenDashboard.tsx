import React from 'react';
import {
  ArrowUpRight,
  BarChart3,
  Lightbulb,
  Megaphone,
  RotateCcw,
  Users,
} from 'lucide-react';
import {
  BusinessProfile,
  CustomerLead,
  MarketingActivity,
  MonthlySampleBenchmark,
  ScreenRoute,
} from '../types/bizgrow';
import { formatInr, formatPercent } from '../utils/formatters';

interface ScreenDashboardProps {
  profile: BusinessProfile;
  leads: CustomerLead[];
  activities: MarketingActivity[];
  sampleBenchmark: MonthlySampleBenchmark;
  metrics: {
    totalLeads: number;
    newCount: number;
    interestedCount: number;
    convertedCount: number;
    conversionRatePercent: number;
    totalMarketingExpenditureInr: number;
    estimatedRevenueInr: number;
    userAddedLeadsCount: number;
    sampleLeadsCount: number;
  };
  onNavigate: (route: ScreenRoute) => void;
  onResetDemo: () => void;
}

const STATUS_TEXT_COLOR: Record<CustomerLead['status'], string> = {
  New: 'text-slate-800',
  Contacted: 'text-sky-700',
  Interested: 'text-amber-700',
  Converted: 'text-emerald-700',
  Lost: 'text-red-600',
};

export const ScreenDashboard: React.FC<ScreenDashboardProps> = ({
  profile,
  leads,
  activities,
  sampleBenchmark,
  metrics,
  onNavigate,
  onResetDemo,
}) => {
  const completedActivities = activities.filter((a) => a.status === 'Completed').length;
  const inProgressActivities = activities.filter((a) => a.status === 'In Progress').length;
  const pendingActivities = activities.filter((a) => a.status === 'Pending').length;

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <section className="bg-[#0B192C] text-white rounded-2xl p-5 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <img
            src="/src/assets/images/sharma_owner_avatar_1795414697921.jpg"
            alt={profile.ownerName}
            referrerPolicy="no-referrer"
            className="w-14 h-14 rounded-2xl object-cover border border-white/15 shrink-0"
          />
          <div>
            <div className="text-xs text-teal-300 font-medium">
              Welcome back, {profile.ownerName} {profile.isDemoUser ? '· Demo Session' : ''}
            </div>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
              {profile.businessName}
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
              {profile.category} · {profile.location}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={onResetDemo}
          className="self-start sm:self-auto min-h-[40px] px-3.5 py-2 text-xs font-medium text-slate-200 hover:text-white border border-white/20 hover:border-white/40 rounded-xl transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset Sample Data</span>
        </button>
      </section>

      {/* Primary Live Calculated KPI Grid */}
      <section aria-labelledby="live-kpis-heading">
        <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1 mb-3">
          <h3 id="live-kpis-heading" className="text-base font-bold text-slate-900">
            Live Business Overview
          </h3>
          <span className="text-xs text-slate-500">
            Updates automatically as you add or convert leads &amp; activities
          </span>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
          <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5">
            <div className="text-xs font-medium text-slate-500">Total Enquiries (Leads)</div>
            <div className="mt-1.5 text-2xl sm:text-3xl font-bold text-slate-900 font-mono-tabular">
              {metrics.totalLeads}
            </div>
            <div className="mt-1 text-xs text-slate-500">
              {metrics.userAddedLeadsCount} user added · {metrics.sampleLeadsCount} sample
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5">
            <div className="text-xs font-medium text-slate-500">New Leads</div>
            <div className="mt-1.5 text-2xl sm:text-3xl font-bold text-[#0B192C] font-mono-tabular">
              {metrics.newCount}
            </div>
            <div className="mt-1 text-xs text-slate-500">Awaiting first response</div>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5">
            <div className="text-xs font-medium text-slate-500">Converted Customers</div>
            <div className="mt-1.5 text-2xl sm:text-3xl font-bold text-emerald-700 font-mono-tabular">
              {metrics.convertedCount}
            </div>
            <div className="mt-1 text-xs text-slate-500">
              {metrics.interestedCount} interested in follow-up
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5">
            <div className="text-xs font-medium text-slate-500">Conversion Rate</div>
            <div className="mt-1.5 text-2xl sm:text-3xl font-bold text-teal-700 font-mono-tabular">
              {formatPercent(metrics.conversionRatePercent)}
            </div>
            <div className="mt-1 text-xs text-slate-500">Converted / Total Leads</div>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5">
            <div className="text-xs font-medium text-slate-500">Monthly Marketing Spend</div>
            <div className="mt-1.5 text-2xl sm:text-3xl font-bold text-slate-900 font-mono-tabular">
              {formatInr(metrics.totalMarketingExpenditureInr)}
            </div>
            <div className="mt-1 text-xs text-slate-500">
              Across {activities.length} active activities
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5">
            <div className="text-xs font-medium text-slate-500">Estimated Revenue</div>
            <div className="mt-1.5 text-2xl sm:text-3xl font-bold text-teal-700 font-mono-tabular">
              {formatInr(metrics.estimatedRevenueInr)}
            </div>
            <div className="mt-1 text-xs text-slate-500">Sample baseline + conversions</div>
          </div>
        </div>
      </section>

      {/* Predefined Sample Monthly Demo Benchmark */}
      <section className="bg-slate-100/90 border border-slate-200 rounded-2xl p-4 sm:p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <div className="text-xs font-semibold text-[#0B192C]">
              Predefined Monthly Business Benchmark (Sample Demo Data)
            </div>
            <p className="text-xs text-slate-600 mt-1 tabular-nums">
              {sampleBenchmark.totalEnquiries} Enquiries · {sampleBenchmark.newLeads} New Leads ·{' '}
              {sampleBenchmark.convertedCustomers} Converted Customers (
              {sampleBenchmark.conversionRatePercent}%) · Budget{' '}
              {formatInr(sampleBenchmark.marketingBudgetInr)} · Est. Revenue{' '}
              {formatInr(sampleBenchmark.estimatedRevenueInr)}
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('reports')}
            className="self-start sm:self-auto text-xs font-semibold text-teal-700 hover:text-teal-800 flex items-center gap-1 whitespace-nowrap shrink-0 min-h-[36px] cursor-pointer"
          >
            <span>Open Analytics</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </section>

      {/* Quick Navigation Modules */}
      <section>
        <h3 className="text-base font-bold text-slate-900 mb-3">Quick Navigation</h3>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <button
            type="button"
            onClick={() => onNavigate('leads')}
            className="bg-white border border-slate-200 hover:border-teal-600 rounded-2xl p-4 text-left transition-colors min-h-[72px] flex flex-col justify-between cursor-pointer"
          >
            <Users className="w-5 h-5 text-teal-700" />
            <div className="mt-2">
              <div className="text-sm font-semibold text-slate-900">Manage Leads</div>
              <div className="text-xs text-slate-500">{metrics.totalLeads} tracked records</div>
            </div>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('marketing')}
            className="bg-white border border-slate-200 hover:border-teal-600 rounded-2xl p-4 text-left transition-colors min-h-[72px] flex flex-col justify-between cursor-pointer"
          >
            <Megaphone className="w-5 h-5 text-[#0B192C]" />
            <div className="mt-2">
              <div className="text-sm font-semibold text-slate-900">Marketing Activities</div>
              <div className="text-xs text-slate-500">
                {formatInr(metrics.totalMarketingExpenditureInr)} budget
              </div>
            </div>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('reports')}
            className="bg-white border border-slate-200 hover:border-teal-600 rounded-2xl p-4 text-left transition-colors min-h-[72px] flex flex-col justify-between cursor-pointer"
          >
            <BarChart3 className="w-5 h-5 text-teal-700" />
            <div className="mt-2">
              <div className="text-sm font-semibold text-slate-900">Reports</div>
              <div className="text-xs text-slate-500">Channel &amp; ROI insights</div>
            </div>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('recommendations')}
            className="bg-white border border-slate-200 hover:border-teal-600 rounded-2xl p-4 text-left transition-colors min-h-[72px] flex flex-col justify-between cursor-pointer"
          >
            <Lightbulb className="w-5 h-5 text-amber-600" />
            <div className="mt-2">
              <div className="text-sm font-semibold text-slate-900">Recommendations</div>
              <div className="text-xs text-slate-500">6 growth playbooks</div>
            </div>
          </button>
        </div>
      </section>

      {/* Two-column Bottom Split: Recent Enquiries & Marketing Performance Summary */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-2xl p-5 flex flex-col">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-base font-bold text-slate-900">Recent Customer Enquiries</h3>
            <button
              type="button"
              onClick={() => onNavigate('leads')}
              className="text-xs font-semibold text-teal-700 hover:text-teal-800 cursor-pointer"
            >
              View All
            </button>
          </div>
          <div className="divide-y divide-slate-100">
            {leads.slice(0, 4).map((lead) => (
              <div
                key={lead.id}
                className="py-3 first:pt-1 last:pb-1 flex items-center justify-between gap-3"
              >
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-slate-900 truncate">
                    {lead.customerName}
                  </div>
                  <div className="text-xs text-slate-500 truncate">
                    {lead.source} · Follow-up {lead.followUpDate} ·{' '}
                    {lead.isSample ? 'Sample Data' : 'User Added'}
                  </div>
                </div>
                <div
                  className={`text-xs font-semibold whitespace-nowrap shrink-0 ${
                    STATUS_TEXT_COLOR[lead.status]
                  }`}
                >
                  {lead.status}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-5 bg-white border border-slate-200 rounded-2xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-base font-bold text-slate-900">Marketing Summary</h3>
              <button
                type="button"
                onClick={() => onNavigate('marketing')}
                className="text-xs font-semibold text-teal-700 hover:text-teal-800 cursor-pointer"
              >
                Manage
              </button>
            </div>

            <div className="space-y-3 text-sm">
              <div className="flex items-center justify-between py-2 border-b border-slate-100">
                <span className="text-slate-600">Completed Activities</span>
                <span className="font-semibold font-mono-tabular text-emerald-700">
                  {completedActivities}
                </span>
              </div>
              <div className="flex items-center justify-between py-2 border-b border-slate-100">
                <span className="text-slate-600">In Progress</span>
                <span className="font-semibold font-mono-tabular text-sky-700">
                  {inProgressActivities}
                </span>
              </div>
              <div className="flex items-center justify-between py-2 border-b border-slate-100">
                <span className="text-slate-600">Pending Launch</span>
                <span className="font-semibold font-mono-tabular text-amber-700">
                  {pendingActivities}
                </span>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-200 flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Total Monthly Expenditure</span>
            <span className="text-lg font-bold text-[#0B192C] font-mono-tabular">
              {formatInr(metrics.totalMarketingExpenditureInr)}
            </span>
          </div>
        </div>
      </section>
    </div>
  );
};
