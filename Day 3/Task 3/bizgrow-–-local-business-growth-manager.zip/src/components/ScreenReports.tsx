import React from 'react';
import {
  CustomerLead,
  LeadSource,
  LeadStatus,
  MonthlySampleBenchmark,
} from '../types/bizgrow';
import { formatInr, formatPercent } from '../utils/formatters';

interface ScreenReportsProps {
  leads: CustomerLead[];
  sampleBenchmark: MonthlySampleBenchmark;
  metrics: {
    totalLeads: number;
    newCount: number;
    contactedCount: number;
    interestedCount: number;
    convertedCount: number;
    lostCount: number;
    conversionRatePercent: number;
    totalMarketingExpenditureInr: number;
    estimatedRevenueInr: number;
  };
}

const LEAD_SOURCES: LeadSource[] = ['Google', 'Instagram', 'Facebook', 'Referral', 'Walk-in'];
const LEAD_STATUSES: LeadStatus[] = ['New', 'Contacted', 'Interested', 'Converted', 'Lost'];

export const ScreenReports: React.FC<ScreenReportsProps> = ({
  leads,
  sampleBenchmark,
  metrics,
}) => {
  const sourceStats = LEAD_SOURCES.map((source) => {
    const items = leads.filter((l) => l.source === source);
    const converted = items.filter((l) => l.status === 'Converted').length;
    return { source, count: items.length, converted };
  });

  const maxLiveSourceCount = Math.max(1, ...sourceStats.map((s) => s.count));
  const maxSampleEnquiries = Math.max(
    1,
    ...sampleBenchmark.channelBreakdown.map((c) => c.enquiries)
  );

  const roiMultiplier =
    metrics.totalMarketingExpenditureInr > 0
      ? metrics.estimatedRevenueInr / metrics.totalMarketingExpenditureInr
      : 0;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold text-slate-900">Reports &amp; Business Analytics</h2>
        <p className="text-xs sm:text-sm text-slate-500">
          Live lead conversion &amp; expenditure telemetry alongside predefined sample monthly
          benchmarks
        </p>
      </div>

      {/* Top 4 KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5">
          <div className="text-xs font-medium text-slate-500">Total Enquiries</div>
          <div className="mt-1 text-2xl font-bold text-slate-900 font-mono-tabular">
            {metrics.totalLeads}
          </div>
          <div className="mt-1 text-xs text-slate-500">Live CRM pipeline</div>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5">
          <div className="text-xs font-medium text-slate-500">Lead Conversion Rate</div>
          <div className="mt-1 text-2xl font-bold text-teal-700 font-mono-tabular">
            {formatPercent(metrics.conversionRatePercent)}
          </div>
          <div className="mt-1 text-xs text-slate-500">
            {metrics.convertedCount} converted customers
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5">
          <div className="text-xs font-medium text-slate-500">Marketing Expenditure</div>
          <div className="mt-1 text-2xl font-bold text-[#0B192C] font-mono-tabular">
            {formatInr(metrics.totalMarketingExpenditureInr)}
          </div>
          <div className="mt-1 text-xs text-slate-500">Sum of entered budgets</div>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5">
          <div className="text-xs font-medium text-slate-500">Estimated Revenue</div>
          <div className="mt-1 text-2xl font-bold text-emerald-700 font-mono-tabular">
            {formatInr(metrics.estimatedRevenueInr)}
          </div>
          <div className="mt-1 text-xs text-slate-500 font-mono-tabular">
            {roiMultiplier.toFixed(1)}x spend ratio
          </div>
        </div>
      </div>

      {/* Charts Split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
        {/* Live Lead Source Performance */}
        <div className="lg:col-span-6 bg-white border border-slate-200 rounded-2xl p-5">
          <div className="flex items-baseline justify-between mb-4">
            <h3 className="text-base font-bold text-slate-900">Lead Source Performance</h3>
            <span className="text-xs text-teal-700 font-semibold">Live Tracker</span>
          </div>

          <div className="space-y-4">
            {sourceStats.map((row) => {
              const widthPct = Math.round((row.count / maxLiveSourceCount) * 100);
              return (
                <div key={row.source}>
                  <div className="flex items-center justify-between text-xs sm:text-sm mb-1.5">
                    <span className="font-semibold text-slate-800">{row.source}</span>
                    <span className="text-slate-500 font-mono-tabular">
                      {row.count} leads · {row.converted} converted
                    </span>
                  </div>
                  <div className="h-2.5 w-full bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-teal-600 rounded-full transition-all duration-300"
                      style={{ width: `${widthPct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Sample Monthly Business Performance Breakdown */}
        <div className="lg:col-span-6 bg-white border border-slate-200 rounded-2xl p-5">
          <div className="flex items-baseline justify-between mb-4">
            <h3 className="text-base font-bold text-slate-900">Monthly Channel Enquiries</h3>
            <span className="text-xs text-slate-500 font-semibold">Sample Data</span>
          </div>

          <div className="space-y-4">
            {sampleBenchmark.channelBreakdown.map((item) => {
              const widthPct = Math.round((item.enquiries / maxSampleEnquiries) * 100);
              return (
                <div key={item.channel}>
                  <div className="flex items-center justify-between text-xs sm:text-sm mb-1.5">
                    <span className="font-semibold text-slate-800">{item.channel}</span>
                    <span className="text-slate-500 font-mono-tabular">
                      {item.enquiries} enquiries (Sample)
                    </span>
                  </div>
                  <div className="h-2.5 w-full bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-[#0B192C] rounded-full"
                      style={{ width: `${widthPct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Lead Pipeline Stage Breakdown */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5">
        <h3 className="text-base font-bold text-slate-900 mb-3">
          Pipeline Stage Distribution (Live)
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
          {LEAD_STATUSES.map((stage) => {
            const count = leads.filter((l) => l.status === stage).length;
            const share = metrics.totalLeads > 0 ? (count / metrics.totalLeads) * 100 : 0;
            return (
              <div
                key={stage}
                className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 text-center"
              >
                <div className="text-xs font-medium text-slate-500">{stage}</div>
                <div className="mt-1 text-xl font-bold text-slate-900 font-mono-tabular">
                  {count}
                </div>
                <div className="text-[11px] text-slate-500 font-mono-tabular">
                  {formatPercent(share)}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Business Performance Summary */}
      <div className="bg-slate-100 border border-slate-200 rounded-2xl p-5">
        <h3 className="text-sm font-bold text-[#0B192C]">Business Performance Summary</h3>
        <p className="mt-1.5 text-sm text-slate-700 leading-relaxed">
          Sharma Digital Services currently tracks{' '}
          <strong className="font-semibold text-slate-900">{metrics.totalLeads} total leads</strong>{' '}
          with{' '}
          <strong className="font-semibold text-emerald-700">
            {metrics.convertedCount} converted customers
          </strong>{' '}
          ({formatPercent(metrics.conversionRatePercent)} conversion rate) on a total marketing
          expenditure of{' '}
          <strong className="font-semibold text-slate-900">
            {formatInr(metrics.totalMarketingExpenditureInr)}
          </strong>
          . Sample historical benchmark data ({sampleBenchmark.totalEnquiries} monthly enquiries,
          Google 40 · Instagram 35 · Facebook 25 · Referrals 20) is labeled above as sample data.
        </p>
      </div>
    </div>
  );
};
