import React, { useState } from 'react';
import { Plus, X } from 'lucide-react';
import { ActivityStatus, MarketingActivity } from '../types/bizgrow';
import { formatInr } from '../utils/formatters';

interface ScreenMarketingProps {
  activities: MarketingActivity[];
  totalExpenditureInr: number;
  onAddActivity: (payload: {
    name: string;
    description: string;
    status: ActivityStatus;
    budgetInr: number;
    targetAudience: string;
    expectedOutcome: string;
  }) => void;
  onUpdateActivityStatus: (activityId: string, status: ActivityStatus) => void;
}

const ACTIVITY_STATUSES: ActivityStatus[] = ['Pending', 'In Progress', 'Completed'];

const ACTIVITY_STATUS_STYLE: Record<ActivityStatus, string> = {
  Pending: 'text-amber-800 border-amber-200 bg-amber-50',
  'In Progress': 'text-sky-800 border-sky-200 bg-sky-50',
  Completed: 'text-emerald-800 border-emerald-200 bg-emerald-50',
};

export const ScreenMarketing: React.FC<ScreenMarketingProps> = ({
  activities,
  totalExpenditureInr,
  onAddActivity,
  onUpdateActivityStatus,
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [budgetInr, setBudgetInr] = useState('');
  const [targetAudience, setTargetAudience] = useState('');
  const [expectedOutcome, setExpectedOutcome] = useState('');
  const [status, setStatus] = useState<ActivityStatus>('Pending');
  const [formError, setFormError] = useState<string | null>(null);

  const handleSaveActivity = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedBudget = Number(budgetInr);
    if (!name.trim()) {
      setFormError('Activity name is required.');
      return;
    }
    if (!description.trim()) {
      setFormError('Description is required.');
      return;
    }
    if (!Number.isFinite(parsedBudget) || parsedBudget <= 0) {
      setFormError('Please enter a valid marketing budget in ₹.');
      return;
    }

    onAddActivity({
      name,
      description,
      status,
      budgetInr: parsedBudget,
      targetAudience,
      expectedOutcome,
    });

    setName('');
    setDescription('');
    setBudgetInr('');
    setTargetAudience('');
    setExpectedOutcome('');
    setStatus('Pending');
    setFormError(null);
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-5">
      {/* Header & Expenditure Total */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Marketing Activities</h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Total Marketing Expenditure:{' '}
            <span className="font-bold text-teal-700 font-mono-tabular">
              {formatInr(totalExpenditureInr)}
            </span>{' '}
            · {activities.length} activities
          </p>
        </div>

        <button
          type="button"
          onClick={() => setIsModalOpen(true)}
          className="min-h-[44px] px-4 py-2.5 bg-[#0B192C] hover:bg-[#132948] text-white text-sm font-semibold rounded-xl transition-colors inline-flex items-center justify-center gap-2 whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add Marketing Activity</span>
        </button>
      </div>

      {/* Empty State or Activity Grid */}
      {activities.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-2xl p-8 text-center">
          <div className="text-base font-semibold text-slate-900">
            No marketing activities recorded
          </div>
          <p className="mt-1 text-sm text-slate-500">
            Add Google Business Profile, Instagram, or WhatsApp campaigns to track spend.
          </p>
          <button
            type="button"
            onClick={() => setIsModalOpen(true)}
            className="mt-4 min-h-[44px] px-4 py-2 bg-[#0B192C] text-white text-sm font-semibold rounded-xl cursor-pointer"
          >
            Add First Activity
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {activities.map((activity) => (
            <div
              key={activity.id}
              className="bg-white border border-slate-200 rounded-2xl p-5 flex flex-col justify-between gap-3.5"
            >
              <div>
                <div className="flex items-start justify-between gap-3">
                  <h3 className="text-base font-bold text-slate-900">{activity.name}</h3>
                  <span className="text-base font-bold text-[#0B192C] font-mono-tabular whitespace-nowrap shrink-0">
                    {formatInr(activity.budgetInr)}
                  </span>
                </div>

                <p className="mt-2 text-sm text-slate-600 leading-relaxed">
                  {activity.description}
                </p>

                <div className="mt-3 space-y-1 text-xs text-slate-600">
                  <div>
                    <span className="font-semibold text-slate-800">Target Audience:</span>{' '}
                    {activity.targetAudience}
                  </div>
                  <div>
                    <span className="font-semibold text-teal-700">Expected Outcome:</span>{' '}
                    {activity.expectedOutcome}
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-3">
                <span
                  className={`text-xs font-semibold ${
                    activity.isSample ? 'text-slate-400' : 'text-teal-700'
                  }`}
                >
                  {activity.isSample ? 'Sample Activity' : 'User Added'}
                </span>

                <select
                  aria-label={`Update status for ${activity.name}`}
                  value={activity.status}
                  onChange={(e) =>
                    onUpdateActivityStatus(activity.id, e.target.value as ActivityStatus)
                  }
                  className={`min-h-[36px] px-3 py-1 text-xs font-semibold border rounded-lg cursor-pointer focus:outline-none focus:ring-2 focus:ring-teal-600/30 ${
                    ACTIVITY_STATUS_STYLE[activity.status]
                  }`}
                >
                  {ACTIVITY_STATUSES.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add Marketing Activity Modal */}
      {isModalOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="add-activity-title"
          className="fixed inset-0 z-50 bg-slate-950/50 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4"
        >
          <div className="bg-white w-full sm:max-w-lg rounded-t-3xl sm:rounded-2xl border border-slate-200 p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 id="add-activity-title" className="text-lg font-bold text-slate-900">
                Add Marketing Activity
              </h3>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 cursor-pointer"
                aria-label="Close modal"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveActivity} className="space-y-3.5">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Activity Name *
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => {
                    setName(e.target.value);
                    setFormError(null);
                  }}
                  placeholder="e.g. Google Local Services Ads"
                  className="w-full min-h-[44px] px-3.5 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-600/30 focus:border-teal-600"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Description *
                </label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => {
                    setDescription(e.target.value);
                    setFormError(null);
                  }}
                  placeholder="Describe campaign scope and deliverables..."
                  className="w-full px-3.5 py-2.5 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-600/30 focus:border-teal-600"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Budget in ₹ (INR) *
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={budgetInr}
                    onChange={(e) => {
                      setBudgetInr(e.target.value);
                      setFormError(null);
                    }}
                    placeholder="2500"
                    className="w-full min-h-[44px] px-3.5 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-600/30 focus:border-teal-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Activity Status
                  </label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as ActivityStatus)}
                    className="w-full min-h-[44px] px-3 py-2 text-sm border border-slate-200 rounded-xl bg-white"
                  >
                    {ACTIVITY_STATUSES.map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Target Audience
                </label>
                <input
                  type="text"
                  value={targetAudience}
                  onChange={(e) => setTargetAudience(e.target.value)}
                  placeholder="e.g. Neighbourhood families in Nagpur"
                  className="w-full min-h-[44px] px-3.5 py-2 text-sm border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Expected Outcome
                </label>
                <input
                  type="text"
                  value={expectedOutcome}
                  onChange={(e) => setExpectedOutcome(e.target.value)}
                  placeholder="e.g. 20+ phone enquiries per month"
                  className="w-full min-h-[44px] px-3.5 py-2 text-sm border border-slate-200 rounded-xl"
                />
              </div>

              {formError && (
                <div className="text-xs font-medium text-red-600 bg-red-50 border border-red-200 rounded-xl px-3.5 py-2.5">
                  {formError}
                </div>
              )}

              <div className="pt-2 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="min-h-[44px] px-4 py-2 text-sm font-medium text-slate-600 hover:text-slate-900 rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="min-h-[44px] px-5 py-2 bg-teal-600 hover:bg-teal-700 text-white text-sm font-semibold rounded-xl cursor-pointer"
                >
                  Save Activity
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
