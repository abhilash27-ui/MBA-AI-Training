import React, { useState } from 'react';
import JSZip from 'jszip';
import { Check, Copy, Download, FileCode2, X } from 'lucide-react';
import { ANDROID_PROJECT_FILES } from '../data/androidProjectFiles';

interface AndroidStudioModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidStudioModal: React.FC<AndroidStudioModalProps> = ({ isOpen, onClose }) => {
  const [selectedPath, setSelectedPath] = useState<string>(ANDROID_PROJECT_FILES[0].path);
  const [copied, setCopied] = useState(false);
  const [downloading, setDownloading] = useState(false);

  if (!isOpen) return null;

  const activeFile =
    ANDROID_PROJECT_FILES.find((f) => f.path === selectedPath) ?? ANDROID_PROJECT_FILES[0];

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(activeFile.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // Clipboard fallback ignored if blocked in iframe
    }
  };

  const handleDownloadZip = async () => {
    setDownloading(true);
    try {
      const zip = new JSZip();
      ANDROID_PROJECT_FILES.forEach((file) => {
        zip.file(file.path, file.content);
      });
      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href = url;
      anchor.download = 'BizGrow-Android-Studio-Project.zip';
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      URL.revokeObjectURL(url);
    } finally {
      setDownloading(false);
    }
  };

  const categories = [
    'Kotlin Screens',
    'MVVM & Data',
    'Theme & Navigation',
    'Gradle & Manifest',
  ] as const;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="android-export-title"
      className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-6"
    >
      <div className="bg-white w-full max-w-6xl h-[88vh] rounded-2xl border border-slate-200 flex flex-col overflow-hidden shadow-2xl">
        {/* Modal Header */}
        <div className="px-5 py-4 bg-[#0B192C] text-white flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div>
            <h2 id="android-export-title" className="text-base sm:text-lg font-bold">
              Native Android Studio Project (Kotlin · Jetpack Compose · Material 3)
            </h2>
            <p className="text-xs text-slate-300 mt-0.5">
              {ANDROID_PROJECT_FILES.length} source files · MVVM ViewModel + SharedPreferences +
              Compose Navigation · Ready to open in Android Studio to build APK
            </p>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={handleDownloadZip}
              disabled={downloading}
              className="min-h-[40px] px-4 py-2 bg-teal-600 hover:bg-teal-500 text-white text-xs sm:text-sm font-semibold rounded-xl transition-colors inline-flex items-center gap-2 whitespace-nowrap cursor-pointer disabled:opacity-60"
            >
              <Download className="w-4 h-4" />
              <span>{downloading ? 'Packaging ZIP...' : 'Download Android Project ZIP'}</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              aria-label="Close source viewer"
              className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-xl text-slate-300 hover:bg-white/10 hover:text-white cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Two-column File Tree & Code Viewer */}
        <div className="flex-1 min-h-0 grid grid-cols-1 md:grid-cols-12">
          <aside className="md:col-span-4 lg:col-span-3 border-b md:border-b-0 md:border-r border-slate-200 bg-slate-50 overflow-y-auto p-3 max-h-56 md:max-h-none">
            {categories.map((cat) => (
              <div key={cat} className="mb-4 last:mb-0">
                <div className="px-2.5 py-1 text-[11px] font-bold text-slate-500">{cat}</div>
                <div className="space-y-0.5">
                  {ANDROID_PROJECT_FILES.filter((f) => f.category === cat).map((file) => {
                    const shortName = file.path.split('/').pop() ?? file.path;
                    const active = file.path === activeFile.path;
                    return (
                      <button
                        key={file.path}
                        type="button"
                        onClick={() => setSelectedPath(file.path)}
                        className={`w-full text-left px-2.5 py-2 rounded-lg text-xs font-medium flex items-center gap-2 transition-colors cursor-pointer ${
                          active
                            ? 'bg-[#0B192C] text-white'
                            : 'text-slate-700 hover:bg-slate-200/70'
                        }`}
                      >
                        <FileCode2 className="w-3.5 h-3.5 shrink-0 opacity-75" />
                        <span className="truncate">{shortName}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </aside>

          <div className="md:col-span-8 lg:col-span-9 flex flex-col min-h-0 bg-slate-950 text-slate-100">
            <div className="px-4 py-2.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between gap-3 shrink-0">
              <span className="text-xs font-mono text-slate-300 truncate">{activeFile.path}</span>
              <button
                type="button"
                onClick={handleCopy}
                className="px-3 py-1.5 text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-teal-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy Code'}</span>
              </button>
            </div>
            <pre className="flex-1 overflow-auto p-4 text-xs leading-relaxed font-mono text-slate-200">
              <code>{activeFile.content}</code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
