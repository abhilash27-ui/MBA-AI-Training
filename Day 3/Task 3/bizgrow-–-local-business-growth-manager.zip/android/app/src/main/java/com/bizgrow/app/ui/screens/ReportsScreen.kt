package com.bizgrow.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.bizgrow.app.model.LeadSource
import com.bizgrow.app.ui.components.BizGrowMetricCard
import com.bizgrow.app.ui.components.SectionHeader
import com.bizgrow.app.ui.components.formatInr
import com.bizgrow.app.ui.theme.*
import com.bizgrow.app.viewmodel.BizGrowUiState
import java.util.Locale

@Composable
fun ReportsScreen(state: BizGrowUiState) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SectionHeader(
                title = "Reports & Business Analytics",
                subtitle = "Live pipeline metrics combined with sample monthly benchmarks"
            )
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                BizGrowMetricCard(
                    title = "Total Enquiries",
                    value = state.totalLeads.toString(),
                    subtitle = "All tracked leads",
                    modifier = Modifier.weight(1f)
                )
                BizGrowMetricCard(
                    title = "Lead Conversion Rate",
                    value = String.format(Locale.US, "%.1f%%", state.conversionRatePercent),
                    subtitle = "${state.convertedLeadsCount} converted",
                    accentColor = TealAccent,
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                BizGrowMetricCard(
                    title = "Marketing Spend",
                    value = formatInr(state.totalMarketingExpenditureInr),
                    subtitle = "${state.activities.size} campaigns",
                    modifier = Modifier.weight(1f)
                )
                BizGrowMetricCard(
                    title = "Estimated Revenue",
                    value = formatInr(state.estimatedRevenueInr),
                    subtitle = "Sample + converted bonus",
                    accentColor = EmeraldSuccess,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = SurfaceCard,
                border = BorderStroke(1.dp, BorderHairline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Lead Source Performance (Live Tracker)", style = MaterialTheme.typography.titleMedium)
                    val maxCount = LeadSource.entries.maxOf { src -> state.leads.count { it.source == src } }.coerceAtLeast(1)
                    LeadSource.entries.forEach { src ->
                        val count = state.leads.count { it.source == src }
                        val converted = state.leads.count { it.source == src && it.status == com.bizgrow.app.model.LeadStatus.CONVERTED }
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(src.label, style = MaterialTheme.typography.bodyMedium)
                                Text(
                                    text = "$count leads · $converted converted",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextMuted
                                )
                            }
                            LinearProgressIndicator(
                                progress = { count.toFloat() / maxCount.toFloat() },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp),
                                color = TealAccent,
                                trackColor = Color(0xFFE2E8F0)
                            )
                        }
                    }
                }
            }
        }

        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = SurfaceCard,
                border = BorderStroke(1.dp, BorderHairline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Monthly Business Performance (Sample Data)",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = "Predefined sample breakdown for Sharma Digital Services:",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )
                    val sampleBreakdown = listOf(
                        "Google" to state.sampleBenchmark.googleEnquiries,
                        "Instagram" to state.sampleBenchmark.instagramEnquiries,
                        "Facebook" to state.sampleBenchmark.facebookEnquiries,
                        "Referrals" to state.sampleBenchmark.referralEnquiries
                    )
                    sampleBreakdown.forEach { (channel, count) ->
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(channel, style = MaterialTheme.typography.bodyMedium)
                                Text("$count enquiries (Sample)", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                            }
                            LinearProgressIndicator(
                                progress = { count / 40f },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(7.dp),
                                color = NavyPrimary,
                                trackColor = Color(0xFFE2E8F0)
                            )
                        }
                    }
                }
            }
        }

        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFFF1F5F9),
                border = BorderStroke(1.dp, BorderHairline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Business Performance Summary",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "With ${state.convertedLeadsCount} converted customers out of ${state.totalLeads} total leads (${String.format(Locale.US, "%.1f%%", state.conversionRatePercent)} conversion) and ${formatInr(state.totalMarketingExpenditureInr)} marketing spend, Google and Instagram continue to drive the strongest local enquiry volume.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )
                }
            }
        }
    }
}
