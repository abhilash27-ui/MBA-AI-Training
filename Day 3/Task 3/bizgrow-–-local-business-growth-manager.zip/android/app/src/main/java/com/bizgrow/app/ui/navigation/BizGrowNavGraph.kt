package com.bizgrow.app.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.bizgrow.app.ui.screens.*
import com.bizgrow.app.ui.theme.NavyPrimary
import com.bizgrow.app.ui.theme.SurfaceCanvas
import com.bizgrow.app.ui.theme.TealAccent
import com.bizgrow.app.viewmodel.BizGrowViewModel

enum class BizGrowRoute(val route: String, val label: String, val icon: ImageVector) {
    WELCOME("welcome", "Welcome", Icons.Rounded.Home),
    DASHBOARD("dashboard", "Dashboard", Icons.Rounded.Dashboard),
    LEADS("leads", "Leads", Icons.Rounded.People),
    MARKETING("marketing", "Marketing", Icons.Rounded.Campaign),
    REPORTS("reports", "Reports", Icons.Rounded.BarChart),
    RECOMMENDATIONS("recommendations", "Advice", Icons.Rounded.Lightbulb)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BizGrowApp(viewModel: BizGrowViewModel) {
    val navController = rememberNavController()
    val uiState by viewModel.uiState.collectAsState()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    val bottomTabs = listOf(
        BizGrowRoute.DASHBOARD,
        BizGrowRoute.LEADS,
        BizGrowRoute.MARKETING,
        BizGrowRoute.REPORTS,
        BizGrowRoute.RECOMMENDATIONS
    )

    val startDestination = if (uiState.isLoggedIn) {
        BizGrowRoute.DASHBOARD.route
    } else {
        BizGrowRoute.WELCOME.route
    }

    val navigateToTab: (BizGrowRoute) -> Unit = { dest ->
        navController.navigate(dest.route) {
            popUpTo(BizGrowRoute.DASHBOARD.route) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    Scaffold(
        containerColor = SurfaceCanvas,
        topBar = {
            if (currentRoute != BizGrowRoute.WELCOME.route) {
                TopAppBar(
                    title = { Text("BizGrow · ${uiState.profile.businessName}") },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = NavyPrimary,
                        titleContentColor = Color.White,
                        actionIconContentColor = Color.White
                    ),
                    actions = {
                        IconButton(onClick = {
                            viewModel.logout()
                            navController.navigate(BizGrowRoute.WELCOME.route) {
                                popUpTo(0) { inclusive = true }
                            }
                        }) {
                            Icon(Icons.AutoMirrored.Rounded.Logout, contentDescription = "Sign Out")
                        }
                    }
                )
            }
        },
        bottomBar = {
            if (currentRoute != BizGrowRoute.WELCOME.route) {
                NavigationBar(containerColor = Color.White) {
                    bottomTabs.forEach { tab ->
                        NavigationBarItem(
                            selected = currentRoute == tab.route,
                            onClick = { navigateToTab(tab) },
                            icon = { Icon(tab.icon, contentDescription = tab.label) },
                            label = { Text(tab.label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = TealAccent,
                                selectedTextColor = TealAccent,
                                indicatorColor = Color(0xFFCCFBF1)
                            )
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = startDestination,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(BizGrowRoute.WELCOME.route) {
                WelcomeLoginScreen(
                    onLogin = { email, businessName ->
                        viewModel.loginWithEmail(email, businessName)
                        navController.navigate(BizGrowRoute.DASHBOARD.route) {
                            popUpTo(BizGrowRoute.WELCOME.route) { inclusive = true }
                        }
                    },
                    onContinueAsDemo = {
                        viewModel.continueAsDemoUser()
                        navController.navigate(BizGrowRoute.DASHBOARD.route) {
                            popUpTo(BizGrowRoute.WELCOME.route) { inclusive = true }
                        }
                    }
                )
            }
            composable(BizGrowRoute.DASHBOARD.route) {
                DashboardScreen(
                    state = uiState,
                    onNavigate = navigateToTab
                )
            }
            composable(BizGrowRoute.LEADS.route) {
                LeadsScreen(
                    state = uiState,
                    onSearchChange = viewModel::updateLeadSearchQuery,
                    onStatusFilterChange = viewModel::updateLeadStatusFilter,
                    onAddLead = viewModel::addLead,
                    onUpdateLeadStatus = viewModel::updateLeadStatus
                )
            }
            composable(BizGrowRoute.MARKETING.route) {
                MarketingScreen(
                    state = uiState,
                    onAddActivity = viewModel::addMarketingActivity,
                    onUpdateActivityStatus = viewModel::updateActivityStatus
                )
            }
            composable(BizGrowRoute.REPORTS.route) {
                ReportsScreen(state = uiState)
            }
            composable(BizGrowRoute.RECOMMENDATIONS.route) {
                RecommendationsScreen(state = uiState)
            }
        }
    }
}
