package com.bizgrow.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.TrendingUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.bizgrow.app.ui.theme.*

@Composable
fun WelcomeLoginScreen(
    onLogin: (email: String, businessName: String?) -> Unit,
    onContinueAsDemo: () -> Unit
) {
    var isRegisterMode by remember { mutableStateOf(false) }
    var businessName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SurfaceCanvas)
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = NavyPrimary,
            modifier = Modifier.size(56.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.TrendingUp,
                    contentDescription = "BizGrow Logo",
                    tint = Color(0xFF14B8A6),
                    modifier = Modifier.size(30.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "BizGrow",
            style = MaterialTheme.typography.headlineMedium.copy(
                fontWeight = FontWeight.ExtraBold,
                color = NavyPrimary
            )
        )
        Text(
            text = "Grow Your Local Business Smarter.",
            style = MaterialTheme.typography.titleMedium,
            color = TealAccent
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Manage customer enquiries, track lead conversions, monitor marketing budgets in ₹, and grow local visibility from one workspace.",
            style = MaterialTheme.typography.bodyMedium,
            color = TextMuted
        )

        Spacer(modifier = Modifier.height(24.dp))

        Surface(
            shape = RoundedCornerShape(20.dp),
            color = SurfaceCard,
            border = BorderStroke(1.dp, BorderHairline),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = if (isRegisterMode) "Create Business Account" else "Sign in to BizGrow",
                    style = MaterialTheme.typography.titleMedium
                )

                if (isRegisterMode) {
                    OutlinedTextField(
                        value = businessName,
                        onValueChange = {
                            businessName = it
                            errorMessage = null
                        },
                        label = { Text("Business Name") },
                        placeholder = { Text("e.g. Sharma Digital Services") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                OutlinedTextField(
                    value = email,
                    onValueChange = {
                        email = it
                        errorMessage = null
                    },
                    label = { Text("Email Address") },
                    placeholder = { Text("owner@yourbusiness.in") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = password,
                    onValueChange = {
                        password = it
                        errorMessage = null
                    },
                    label = { Text("Password") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMessage != null) {
                    Text(
                        text = errorMessage!!,
                        style = MaterialTheme.typography.bodySmall,
                        color = CrimsonAlert
                    )
                }

                Button(
                    onClick = {
                        if (email.isBlank() || !email.contains("@")) {
                            errorMessage = "Please enter a valid business email address."
                        } else if (password.length < 4) {
                            errorMessage = "Password must be at least 4 characters."
                        } else if (isRegisterMode && businessName.isBlank()) {
                            errorMessage = "Please enter your business name."
                        } else {
                            onLogin(email, if (isRegisterMode) businessName else null)
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
                ) {
                    Text(if (isRegisterMode) "Register & Open Dashboard" else "Login")
                }

                OutlinedButton(
                    onClick = onContinueAsDemo,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, TealAccent)
                ) {
                    Text(
                        text = "Continue as Demo User",
                        color = TealAccent,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                TextButton(
                    onClick = {
                        isRegisterMode = !isRegisterMode
                        errorMessage = null
                    },
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                ) {
                    Text(
                        text = if (isRegisterMode) {
                            "Already registered? Login instead"
                        } else {
                            "New to BizGrow? Register your business"
                        },
                        color = NavySecondary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Demo Workspace: Sharma Digital Services · Nagpur, Maharashtra (₹ INR)",
            style = MaterialTheme.typography.labelMedium,
            color = TextMuted
        )
    }
}
