package com.bizgrow.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val NavyPrimary = Color(0xFF0B192C)
val NavySecondary = Color(0xFF1E3A5F)
val TealAccent = Color(0xFF0D9488)
val TealContainer = Color(0xFFCCFBF1)
val EmeraldSuccess = Color(0xFF16A34A)
val AmberWarning = Color(0xFFD97706)
val CrimsonAlert = Color(0xFFDC2626)
val SurfaceCanvas = Color(0xFFF8FAFC)
val SurfaceCard = Color(0xFFFFFFFF)
val BorderHairline = Color(0xFFE2E8F0)
val TextPrimary = Color(0xFF0F172A)
val TextMuted = Color(0xFF64748B)

private val BizGrowColorScheme = lightColorScheme(
    primary = NavyPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE2E8F0),
    onPrimaryContainer = NavyPrimary,
    secondary = TealAccent,
    onSecondary = Color.White,
    secondaryContainer = TealContainer,
    onSecondaryContainer = Color(0xFF115E59),
    background = SurfaceCanvas,
    onBackground = TextPrimary,
    surface = SurfaceCard,
    onSurface = TextPrimary,
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = TextMuted,
    outline = BorderHairline,
    error = CrimsonAlert
)

private val BizGrowTypography = Typography(
    headlineMedium = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 24.sp,
        lineHeight = 32.sp,
        color = TextPrimary
    ),
    titleLarge = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 20.sp,
        lineHeight = 28.sp,
        color = TextPrimary
    ),
    titleMedium = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        lineHeight = 24.sp,
        color = TextPrimary
    ),
    bodyMedium = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 20.sp,
        color = TextPrimary
    ),
    labelMedium = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        lineHeight = 16.sp,
        color = TextMuted
    )
)

@Composable
fun BizGrowTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = BizGrowColorScheme,
        typography = BizGrowTypography,
        content = content
    )
}
