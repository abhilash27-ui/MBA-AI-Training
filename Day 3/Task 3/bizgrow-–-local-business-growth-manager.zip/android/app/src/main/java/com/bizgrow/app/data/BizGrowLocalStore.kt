package com.bizgrow.app.data

import android.content.Context
import com.bizgrow.app.model.*
import org.json.JSONArray
import org.json.JSONObject

class BizGrowLocalStore(context: Context) {

    private val prefs = context.getSharedPreferences("bizgrow_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_LEADS = "leads_json"
        private const val KEY_ACTIVITIES = "activities_json"
        private const val KEY_PROFILE = "profile_json"
        private const val KEY_LOGGED_IN = "is_logged_in"
    }

    fun isLoggedIn(): Boolean = prefs.getBoolean(KEY_LOGGED_IN, false)

    fun setLoggedIn(loggedIn: Boolean) {
        prefs.edit().putBoolean(KEY_LOGGED_IN, loggedIn).apply()
    }

    fun loadProfile(): BusinessProfile {
        val raw = prefs.getString(KEY_PROFILE, null) ?: return SampleData.defaultBusinessProfile
        return try {
            val obj = JSONObject(raw)
            BusinessProfile(
                businessName = obj.optString("businessName", SampleData.defaultBusinessProfile.businessName),
                category = obj.optString("category", SampleData.defaultBusinessProfile.category),
                location = obj.optString("location", SampleData.defaultBusinessProfile.location),
                ownerName = obj.optString("ownerName", SampleData.defaultBusinessProfile.ownerName),
                email = obj.optString("email", SampleData.defaultBusinessProfile.email),
                isDemoUser = obj.optBoolean("isDemoUser", true)
            )
        } catch (_: Exception) {
            SampleData.defaultBusinessProfile
        }
    }

    fun saveProfile(profile: BusinessProfile) {
        val obj = JSONObject().apply {
            put("businessName", profile.businessName)
            put("category", profile.category)
            put("location", profile.location)
            put("ownerName", profile.ownerName)
            put("email", profile.email)
            put("isDemoUser", profile.isDemoUser)
        }
        prefs.edit().putString(KEY_PROFILE, obj.toString()).apply()
    }

    fun loadLeads(): List<CustomerLead> {
        val raw = prefs.getString(KEY_LEADS, null) ?: return SampleData.sampleLeads
        return try {
            val arr = JSONArray(raw)
            val result = mutableListOf<CustomerLead>()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                result.add(
                    CustomerLead(
                        id = obj.getString("id"),
                        customerName = obj.getString("customerName"),
                        mobileNumber = obj.getString("mobileNumber"),
                        email = obj.optString("email", ""),
                        businessRequirement = obj.getString("businessRequirement"),
                        source = LeadSource.valueOf(obj.getString("source")),
                        status = LeadStatus.valueOf(obj.getString("status")),
                        followUpDate = obj.optString("followUpDate", ""),
                        isSample = obj.optBoolean("isSample", false)
                    )
                )
            }
            result
        } catch (_: Exception) {
            SampleData.sampleLeads
        }
    }

    fun saveLeads(leads: List<CustomerLead>) {
        val arr = JSONArray()
        leads.forEach { lead ->
            arr.put(JSONObject().apply {
                put("id", lead.id)
                put("customerName", lead.customerName)
                put("mobileNumber", lead.mobileNumber)
                put("email", lead.email)
                put("businessRequirement", lead.businessRequirement)
                put("source", lead.source.name)
                put("status", lead.status.name)
                put("followUpDate", lead.followUpDate)
                put("isSample", lead.isSample)
            })
        }
        prefs.edit().putString(KEY_LEADS, arr.toString()).apply()
    }

    fun loadActivities(): List<MarketingActivity> {
        val raw = prefs.getString(KEY_ACTIVITIES, null) ?: return SampleData.sampleActivities
        return try {
            val arr = JSONArray(raw)
            val result = mutableListOf<MarketingActivity>()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                result.add(
                    MarketingActivity(
                        id = obj.getString("id"),
                        name = obj.getString("name"),
                        description = obj.getString("description"),
                        status = ActivityStatus.valueOf(obj.getString("status")),
                        budgetInr = obj.getDouble("budgetInr"),
                        targetAudience = obj.getString("targetAudience"),
                        expectedOutcome = obj.getString("expectedOutcome"),
                        isSample = obj.optBoolean("isSample", false)
                    )
                )
            }
            result
        } catch (_: Exception) {
            SampleData.sampleActivities
        }
    }

    fun saveActivities(activities: List<MarketingActivity>) {
        val arr = JSONArray()
        activities.forEach { act ->
            arr.put(JSONObject().apply {
                put("id", act.id)
                put("name", act.name)
                put("description", act.description)
                put("status", act.status.name)
                put("budgetInr", act.budgetInr)
                put("targetAudience", act.targetAudience)
                put("expectedOutcome", act.expectedOutcome)
                put("isSample", act.isSample)
            })
        }
        prefs.edit().putString(KEY_ACTIVITIES, arr.toString()).apply()
    }

    fun resetToSampleData() {
        saveLeads(SampleData.sampleLeads)
        saveActivities(SampleData.sampleActivities)
        saveProfile(SampleData.defaultBusinessProfile)
    }
}
