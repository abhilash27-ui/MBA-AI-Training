package com.bizgrow.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.bizgrow.app.model.ActivityStatus
import com.bizgrow.app.ui.components.*
import com.bizgrow.app.ui.theme.*
import com.bizgrow.app.viewmodel.BizGrowUiState

@Composable
fun MarketingScreen(
    state: BizGrowUiState,
    onAddActivity: (
        name: String,
        description: String,
        status: ActivityStatus,
        budgetInr: Double,
        targetAudience: String,
        expectedOutcome: String
    ) -> Unit,
    onUpdateActivityStatus: (activityId: String, newStatus: ActivityStatus) -> Unit
) {
    var showAddDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Marketing Activities", style = MaterialTheme.typography.titleLarge)
                Text(
                    text = "Total Expenditure: ${formatInr(state.totalMarketingExpenditureInr)}",
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                    color = TealAccent
                )
            }
            Button(
                onClick = { showAddDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Add Activity")
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (state.activities.isEmpty()) {
            EmptyStateCard(
                title = "No marketing activities recorded",
                message = "Add campaigns like Google Business Profile, Instagram, or WhatsApp promotions to track total spend.",
                actionLabel = "Add First Activity",
                onAction = { showAddDialog = true }
            )
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 20.dp)
            ) {
                items(state.activities, key = { it.id }) { activity ->
                    var menuExpanded by remember { mutableStateOf(false) }

                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = SurfaceCard,
                        border = BorderStroke(1.dp, BorderHairline),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = activity.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = formatInr(activity.budgetInr),
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = NavyPrimary
                                    )
                                )
                            }

                            Text(
                                text = activity.description,
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextMuted
                            )

                            Text(
                                text = "Audience: ${activity.targetAudience}",
                                style = MaterialTheme.typography.bodySmall
                            )
                            Text(
                                text = "Expected Outcome: ${activity.expectedOutcome}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TealAccent
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                SampleOrUserLabel(isSample = activity.isSample)
                                Box {
                                    OutlinedButton(
                                        onClick = { menuExpanded = true },
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Text(
                                            text = activity.status.label,
                                            color = activityStatusColor(activity.status),
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                    DropdownMenu(
                                        expanded = menuExpanded,
                                        onDismissRequest = { menuExpanded = false }
                                    ) {
                                        ActivityStatus.entries.forEach { candidate ->
                                            DropdownMenuItem(
                                                text = { Text(candidate.label) },
                                                onClick = {
                                                    onUpdateActivityStatus(activity.id, candidate)
                                                    menuExpanded = false
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddActivityDialog(
            onDismiss = { showAddDialog = false },
            onSave = { name, desc, status, budget, audience, outcome ->
                onAddActivity(name, desc, status, budget, audience, outcome)
                showAddDialog = false
            }
        )
    }
}

@Composable
private fun AddActivityDialog(
    onDismiss: () -> Unit,
    onSave: (String, String, ActivityStatus, Double, String, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var budgetText by remember { mutableStateOf("") }
    var audience by remember { mutableStateOf("") }
    var outcome by remember { mutableStateOf("") }
    var status by remember { mutableStateOf(ActivityStatus.PENDING) }
    var errorText by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Marketing Activity") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it; errorText = null },
                    label = { Text("Activity Name *") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it; errorText = null },
                    label = { Text("Description *") }
                )
                OutlinedTextField(
                    value = budgetText,
                    onValueChange = { budgetText = it; errorText = null },
                    label = { Text("Budget in ₹ (INR) *") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = audience,
                    onValueChange = { audience = it },
                    label = { Text("Target Audience") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = outcome,
                    onValueChange = { outcome = it },
                    label = { Text("Expected Outcome") },
                    singleLine = true
                )
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ActivityStatus.entries.forEach { st ->
                        FilterChip(
                            selected = status == st,
                            onClick = { status = st },
                            label = { Text(st.label) }
                        )
                    }
                }
                if (errorText != null) {
                    Text(errorText!!, color = CrimsonAlert, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val parsedBudget = budgetText.toDoubleOrNull()
                    when {
                        name.isBlank() -> errorText = "Activity name is required."
                        description.isBlank() -> errorText = "Description is required."
                        parsedBudget == null || parsedBudget <= 0 -> errorText = "Enter a valid budget in ₹."
                        else -> onSave(
                            name,
                            description,
                            status,
                            parsedBudget,
                            audience.ifBlank { "Local Nagpur customers" },
                            outcome.ifBlank { "Increase local enquiries" }
                        )
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = TealAccent)
            ) { Text("Add Activity") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
