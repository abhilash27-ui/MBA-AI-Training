package com.bizgrow.app.data

import com.bizgrow.app.model.*

object SampleData {

    val defaultBusinessProfile = BusinessProfile(
        businessName = "Sharma Digital Services",
        category = "Local Digital Marketing Agency",
        location = "Nagpur, Maharashtra, India",
        ownerName = "Rajesh Sharma",
        email = "demo@sharmadigital.in",
        isDemoUser = true
    )

    val sampleBenchmark = MonthlySampleBenchmark()

    val sampleLeads: List<CustomerLead> = listOf(
        CustomerLead(
            id = "sample_lead_1",
            customerName = "Aarav Deshmukh",
            mobileNumber = "9823045112",
            email = "aarav@deshmukhsweets.in",
            businessRequirement = "Google Business Profile setup & local SEO for Sitabuldi sweet shop",
            source = LeadSource.GOOGLE,
            status = LeadStatus.CONVERTED,
            followUpDate = "2026-11-18",
            isSample = true
        ),
        CustomerLead(
            id = "sample_lead_2",
            customerName = "Priya Kulkarni",
            mobileNumber = "9765128904",
            email = "priya@glowupsalon.in",
            businessRequirement = "Instagram Reels package & bridal offer promotions",
            source = LeadSource.INSTAGRAM,
            status = LeadStatus.INTERESTED,
            followUpDate = "2026-11-24",
            isSample = true
        ),
        CustomerLead(
            id = "sample_lead_3",
            customerName = "Vikram Joshi",
            mobileNumber = "9890112233",
            email = "vikram@apexcoaching.in",
            businessRequirement = "Admission lead generation campaign on Facebook & Google",
            source = LeadSource.FACEBOOK,
            status = LeadStatus.NEW,
            followUpDate = "2026-11-25",
            isSample = true
        ),
        CustomerLead(
            id = "sample_lead_4",
            customerName = "Sneha Patwardhan",
            mobileNumber = "9422109876",
            email = "sneha@cafesaffron.in",
            businessRequirement = "Google Maps review growth & weekend menu WhatsApp broadcasts",
            source = LeadSource.REFERRAL,
            status = LeadStatus.CONVERTED,
            followUpDate = "2026-11-15",
            isSample = true
        ),
        CustomerLead(
            id = "sample_lead_5",
            customerName = "Rohan Meshram",
            mobileNumber = "9011223344",
            email = "rohan@meshramhardware.in",
            businessRequirement = "Local search visibility for plumbing & hardware store in Dharampeth",
            source = LeadSource.WALK_IN,
            status = LeadStatus.CONTACTED,
            followUpDate = "2026-11-26",
            isSample = true
        ),
        CustomerLead(
            id = "sample_lead_6",
            customerName = "Ananya Verma",
            mobileNumber = "9822334455",
            email = "ananya@vermadental.in",
            businessRequirement = "Patient enquiry landing page and Google Search ads",
            source = LeadSource.GOOGLE,
            status = LeadStatus.CONVERTED,
            followUpDate = "2026-11-12",
            isSample = true
        ),
        CustomerLead(
            id = "sample_lead_7",
            customerName = "Kunal Agrawal",
            mobileNumber = "9373110099",
            email = "kunal@agrawalfashions.in",
            businessRequirement = "Festive ethnic collection catalog ads on Instagram",
            source = LeadSource.INSTAGRAM,
            status = LeadStatus.NEW,
            followUpDate = "2026-11-27",
            isSample = true
        ),
        CustomerLead(
            id = "sample_lead_8",
            customerName = "Meera Bhosale",
            mobileNumber = "9850667788",
            email = "meera@fitzonegym.in",
            businessRequirement = "New Year membership lead ads and WhatsApp follow-up",
            source = LeadSource.FACEBOOK,
            status = LeadStatus.INTERESTED,
            followUpDate = "2026-11-28",
            isSample = true
        ),
        CustomerLead(
            id = "sample_lead_9",
            customerName = "Siddharth Tiwari",
            mobileNumber = "9764554433",
            email = "siddharth@tiwarielectricals.in",
            businessRequirement = "Website refresh and Google Maps pin verification",
            source = LeadSource.GOOGLE,
            status = LeadStatus.CONTACTED,
            followUpDate = "2026-11-29",
            isSample = true
        ),
        CustomerLead(
            id = "sample_lead_10",
            customerName = "Neha Chawla",
            mobileNumber = "9881229900",
            email = "neha@chawlabakery.in",
            businessRequirement = "Custom cake order enquiries via Instagram & WhatsApp",
            source = LeadSource.REFERRAL,
            status = LeadStatus.NEW,
            followUpDate = "2026-11-30",
            isSample = true
        ),
        CustomerLead(
            id = "sample_lead_11",
            customerName = "Pratik Gadkari",
            mobileNumber = "9545887766",
            email = "pratik@gadkarimotors.in",
            businessRequirement = "Two-wheeler servicing reminder campaign",
            source = LeadSource.GOOGLE,
            status = LeadStatus.LOST,
            followUpDate = "2026-11-10",
            isSample = true
        ),
        CustomerLead(
            id = "sample_lead_12",
            customerName = "Divya Nair",
            mobileNumber = "9923445566",
            email = "divya@nairyogastudio.in",
            businessRequirement = "Morning batch enquiry reels and local discovery",
            source = LeadSource.INSTAGRAM,
            status = LeadStatus.INTERESTED,
            followUpDate = "2026-12-01",
            isSample = true
        )
    )

    val sampleActivities: List<MarketingActivity> = listOf(
        MarketingActivity(
            id = "sample_act_1",
            name = "Google Business Profile Optimization",
            description = "Update Nagpur store photos, weekly posts, service categories, and Q&A",
            status = ActivityStatus.COMPLETED,
            budgetInr = 2500.0,
            targetAudience = "Local shoppers within 8 km of Sitabuldi & Dharampeth",
            expectedOutcome = "+35% Google Maps direction & call enquiries",
            isSample = true
        ),
        MarketingActivity(
            id = "sample_act_2",
            name = "Instagram Marketing",
            description = "12 short Reels showcasing local client transformations and festive offers",
            status = ActivityStatus.IN_PROGRESS,
            budgetInr = 3500.0,
            targetAudience = "Ages 21-40 in Nagpur urban neighbourhoods",
            expectedOutcome = "25-40 DM & WhatsApp enquiries per month",
            isSample = true
        ),
        MarketingActivity(
            id = "sample_act_3",
            name = "Facebook Campaigns",
            description = "Geo-targeted lead form ads for coaching institutes and retail stores",
            status = ActivityStatus.IN_PROGRESS,
            budgetInr = 3000.0,
            targetAudience = "Local SMB owners & parents in Nagpur district",
            expectedOutcome = "20+ verified phone leads under ₹150 CPL",
            isSample = true
        ),
        MarketingActivity(
            id = "sample_act_4",
            name = "WhatsApp Marketing",
            description = "Broadcast catalog updates and festival packages to past customer opt-ins",
            status = ActivityStatus.COMPLETED,
            budgetInr = 1500.0,
            targetAudience = "Existing repeat buyers and warm enquiries",
            expectedOutcome = "18% repeat enquiry response rate",
            isSample = true
        ),
        MarketingActivity(
            id = "sample_act_5",
            name = "SEO Activities",
            description = "On-page local keyword optimization and directory citations",
            status = ActivityStatus.IN_PROGRESS,
            budgetInr = 3000.0,
            targetAudience = "High-intent 'near me' Google searchers",
            expectedOutcome = "Top 3 local pack ranking for 5 core services",
            isSample = true
        ),
        MarketingActivity(
            id = "sample_act_6",
            name = "Customer Review Management",
            description = "QR review cards and polite post-service SMS follow-up for Google reviews",
            status = ActivityStatus.PENDING,
            budgetInr = 1500.0,
            targetAudience = "Recently converted happy customers",
            expectedOutcome = "15+ new 5-star Google reviews this month",
            isSample = true
        )
    )

    val sampleRecommendations: List<BusinessRecommendation> = listOf(
        BusinessRecommendation(
            id = "rec_1",
            title = "Improve your Google Business Profile to increase local visibility",
            explanation = "Google brings the highest share of high-intent local enquiries. Complete service listings, fresh storefront photos, and weekly offer posts improve map pack ranking.",
            priority = PriorityLevel.HIGH,
            suggestedAction = "Upload 5 new project photos, verify business hours, and publish a weekly update on Google Business Profile.",
            expectedBenefit = "Up to 30-40% more calls and direction taps from nearby customers",
            isSample = true
        ),
        BusinessRecommendation(
            id = "rec_2",
            title = "Post consistently on Instagram",
            explanation = "Short 20-30 second Reels showing real customer results, behind-the-scenes work, and pricing clarity build trust faster than static flyers.",
            priority = PriorityLevel.MEDIUM,
            suggestedAction = "Schedule 3 Reels per week highlighting Nagpur client stories and include a clear WhatsApp call-to-action.",
            expectedBenefit = "Steady organic discovery and lower cost per enquiry on social ads",
            isSample = true
        ),
        BusinessRecommendation(
            id = "rec_3",
            title = "Respond to customer enquiries quickly",
            explanation = "Local customers often contact 2-3 businesses at once. Replying within 15 minutes dramatically improves your chance of booking a call.",
            priority = PriorityLevel.HIGH,
            suggestedAction = "Enable WhatsApp quick-reply templates and call every New lead within 30 minutes of enquiry.",
            expectedBenefit = "Higher New-to-Contacted speed and fewer lost leads",
            isSample = true
        ),
        BusinessRecommendation(
            id = "rec_4",
            title = "Follow up with interested leads",
            explanation = "Many Interested prospects delay decisions due to budget questions or busy schedules rather than lack of need.",
            priority = PriorityLevel.HIGH,
            suggestedAction = "Review leads with Interested status every morning and send a concise follow-up quote before their due date.",
            expectedBenefit = "Converts warm pipeline enquiries into paying customers without extra ad spend",
            isSample = true
        ),
        BusinessRecommendation(
            id = "rec_5",
            title = "Encourage satisfied customers to leave Google reviews",
            explanation = "Businesses with 4.5+ ratings and recent customer reviews earn noticeably higher click-through rates in local searches.",
            priority = PriorityLevel.MEDIUM,
            suggestedAction = "Share a direct Google review link via WhatsApp immediately after delivering a successful service.",
            expectedBenefit = "Stronger social proof and higher organic trust",
            isSample = true
        ),
        BusinessRecommendation(
            id = "rec_6",
            title = "Monitor marketing expenditure and lead conversion",
            explanation = "Tracking budget per channel alongside actual Converted customers helps pause underperforming ads and double down on profitable channels.",
            priority = PriorityLevel.LOW,
            suggestedAction = "Compare monthly channel spend against converted revenue in the Reports tab every Friday.",
            expectedBenefit = "Better return on marketing budget (₹) and reduced wasted spend",
            isSample = true
        )
    )
}
