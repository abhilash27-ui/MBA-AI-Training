package com.bizgrow.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.bizgrow.app.data.BizGrowLocalStore
import com.bizgrow.app.data.SampleData
import com.bizgrow.app.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.UUID

data class BizGrowUiState(
    val isLoggedIn: Boolean = false,
    val profile: BusinessProfile = SampleData.defaultBusinessProfile,
    val leads: List<CustomerLead> = emptyList(),
    val activities: List<MarketingActivity> = emptyList(),
    val recommendations: List<BusinessRecommendation> = SampleData.sampleRecommendations,
    val leadSearchQuery: String = "",
    val selectedLeadStatusFilter: LeadStatus? = null,
    val sampleBenchmark: MonthlySampleBenchmark = SampleData.sampleBenchmark
) {
    // Business Logic Calculations (Section 7)
    val totalLeads: Int
        get() = leads.size // New + Contacted + Interested + Converted + Lost

    val newLeadsCount: Int
        get() = leads.count { it.status == LeadStatus.NEW }

    val contactedLeadsCount: Int
        get() = leads.count { it.status == LeadStatus.CONTACTED }

    val interestedLeadsCount: Int
        get() = leads.count { it.status == LeadStatus.INTERESTED }

    val convertedLeadsCount: Int
        get() = leads.count { it.status == LeadStatus.CONVERTED }

    val lostLeadsCount: Int
        get() = leads.count { it.status == LeadStatus.LOST }

    val conversionRatePercent: Double
        get() = if (totalLeads == 0) 0.0 else (convertedLeadsCount.toDouble() / totalLeads.toDouble()) * 100.0

    val totalMarketingExpenditureInr: Double
        get() = activities.sumOf { it.budgetInr }

    val estimatedRevenueInr: Double
        get() {
            // Base sample revenue plus ₹12,500 average deal value per converted customer
            val userConvertedBonus = leads.count { !it.isSample && it.status == LeadStatus.CONVERTED } * 12500.0
            val sampleConvertedDelta = (convertedLeadsCount - 3).coerceAtLeast(0) * 12500.0
            return 85000.0 + maxOf(userConvertedBonus, sampleConvertedDelta)
        }

    val filteredLeads: List<CustomerLead>
        get() = leads.filter { lead ->
            val matchesStatus = selectedLeadStatusFilter == null || lead.status == selectedLeadStatusFilter
            val query = leadSearchQuery.trim().lowercase()
            val matchesQuery = query.isEmpty() ||
                lead.customerName.lowercase().contains(query) ||
                lead.mobileNumber.lowercase().contains(query) ||
                lead.email.lowercase().contains(query) ||
                lead.businessRequirement.lowercase().contains(query) ||
                lead.source.label.lowercase().contains(query)
            matchesStatus && matchesQuery
        }
}

class BizGrowViewModel(application: Application) : AndroidViewModel(application) {

    private val localStore = BizGrowLocalStore(application.applicationContext)

    private val _uiState = MutableStateFlow(
        BizGrowUiState(
            isLoggedIn = localStore.isLoggedIn(),
            profile = localStore.loadProfile(),
            leads = localStore.loadLeads(),
            activities = localStore.loadActivities()
        )
    )
    val uiState: StateFlow<BizGrowUiState> = _uiState.asStateFlow()

    fun loginWithEmail(email: String, businessNameInput: String? = null) {
        val cleanEmail = email.trim().ifEmpty { "owner@sharmadigital.in" }
        val updatedProfile = _uiState.value.profile.copy(
            email = cleanEmail,
            businessName = businessNameInput?.trim()?.takeIf { it.isNotEmpty() }
                ?: _uiState.value.profile.businessName,
            isDemoUser = false
        )
        localStore.saveProfile(updatedProfile)
        localStore.setLoggedIn(true)
        _uiState.update { it.copy(isLoggedIn = true, profile = updatedProfile) }
    }

    fun continueAsDemoUser() {
        val demoProfile = SampleData.defaultBusinessProfile
        localStore.saveProfile(demoProfile)
        localStore.setLoggedIn(true)
        _uiState.update { it.copy(isLoggedIn = true, profile = demoProfile) }
    }

    fun logout() {
        localStore.setLoggedIn(false)
        _uiState.update { it.copy(isLoggedIn = false) }
    }

    fun updateLeadSearchQuery(query: String) {
        _uiState.update { it.copy(leadSearchQuery = query) }
    }

    fun updateLeadStatusFilter(status: LeadStatus?) {
        _uiState.update { it.copy(selectedLeadStatusFilter = status) }
    }

    fun addLead(
        customerName: String,
        mobileNumber: String,
        email: String,
        businessRequirement: String,
        source: LeadSource,
        status: LeadStatus,
        followUpDate: String
    ) {
        val newLead = CustomerLead(
            id = "lead_${UUID.randomUUID()}",
            customerName = customerName.trim(),
            mobileNumber = mobileNumber.trim(),
            email = email.trim(),
            businessRequirement = businessRequirement.trim(),
            source = source,
            status = status,
            followUpDate = followUpDate.trim(),
            isSample = false
        )
        val updatedLeads = listOf(newLead) + _uiState.value.leads
        localStore.saveLeads(updatedLeads)
        _uiState.update { it.copy(leads = updatedLeads) }
    }

    fun updateLeadStatus(leadId: String, newStatus: LeadStatus) {
        val updatedLeads = _uiState.value.leads.map { lead ->
            if (lead.id == leadId) lead.copy(status = newStatus) else lead
        }
        localStore.saveLeads(updatedLeads)
        _uiState.update { it.copy(leads = updatedLeads) }
    }

    fun addMarketingActivity(
        name: String,
        description: String,
        status: ActivityStatus,
        budgetInr: Double,
        targetAudience: String,
        expectedOutcome: String
    ) {
        val newActivity = MarketingActivity(
            id = "act_${UUID.randomUUID()}",
            name = name.trim(),
            description = description.trim(),
            status = status,
            budgetInr = budgetInr,
            targetAudience = targetAudience.trim(),
            expectedOutcome = expectedOutcome.trim(),
            isSample = false
        )
        val updatedActivities = listOf(newActivity) + _uiState.value.activities
        localStore.saveActivities(updatedActivities)
        _uiState.update { it.copy(activities = updatedActivities) }
    }

    fun updateActivityStatus(activityId: String, newStatus: ActivityStatus) {
        val updatedActivities = _uiState.value.activities.map { activity ->
            if (activity.id == activityId) activity.copy(status = newStatus) else activity
        }
        localStore.saveActivities(updatedActivities)
        _uiState.update { it.copy(activities = updatedActivities) }
    }

    fun resetDemoData() {
        localStore.resetToSampleData()
        _uiState.update {
            it.copy(
                leads = SampleData.sampleLeads,
                activities = SampleData.sampleActivities,
                profile = SampleData.defaultBusinessProfile
            )
        }
    }
}
