package com.bizgrow.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.bizgrow.app.model.LeadSource
import com.bizgrow.app.model.LeadStatus
import com.bizgrow.app.ui.components.*
import com.bizgrow.app.ui.theme.*
import com.bizgrow.app.viewmodel.BizGrowUiState

@Composable
fun LeadsScreen(
    state: BizGrowUiState,
    onSearchChange: (String) -> Unit,
    onStatusFilterChange: (LeadStatus?) -> Unit,
    onAddLead: (
        customerName: String,
        mobileNumber: String,
        email: String,
        businessRequirement: String,
        source: LeadSource,
        status: LeadStatus,
        followUpDate: String
    ) -> Unit,
    onUpdateLeadStatus: (leadId: String, newStatus: LeadStatus) -> Unit
) {
    var showAddDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Customer Leads", style = MaterialTheme.typography.titleLarge)
                Text(
                    text = "Total Leads: ${state.totalLeads} (${state.convertedLeadsCount} converted)",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextMuted
                )
            }
            Button(
                onClick = { showAddDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = TealAccent),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Add Lead")
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = state.leadSearchQuery,
            onValueChange = onSearchChange,
            leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
            placeholder = { Text("Search name, phone, source, requirement") },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = state.selectedLeadStatusFilter == null,
                onClick = { onStatusFilterChange(null) },
                label = { Text("All (${state.totalLeads})") }
            )
            LeadStatus.entries.forEach { status ->
                val count = state.leads.count { it.status == status }
                FilterChip(
                    selected = state.selectedLeadStatusFilter == status,
                    onClick = { onStatusFilterChange(status) },
                    label = { Text("${status.label} ($count)") }
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        val displayedLeads = state.filteredLeads
        if (displayedLeads.isEmpty()) {
            EmptyStateCard(
                title = "No matching customer leads",
                message = "Try clearing your search or add a new customer enquiry to track.",
                actionLabel = "Add New Lead",
                onAction = { showAddDialog = true }
            )
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 20.dp)
            ) {
                items(displayedLeads, key = { it.id }) { lead ->
                    var statusMenuExpanded by remember { mutableStateOf(false) }

                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = SurfaceCard,
                        border = BorderStroke(1.dp, BorderHairline),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = lead.customerName,
                                    style = MaterialTheme.typography.titleMedium
                                )
                                SampleOrUserLabel(isSample = lead.isSample)
                            }
                            Text(
                                text = "${lead.mobileNumber} · ${lead.email.ifBlank { "No email" }}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextMuted
                            )
                            Text(
                                text = lead.businessRequirement,
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${lead.source.label} · Follow-up: ${lead.followUpDate}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = TextMuted
                                )
                                Box {
                                    OutlinedButton(
                                        onClick = { statusMenuExpanded = true },
                                        shape = RoundedCornerShape(10.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = lead.status.label,
                                            color = leadStatusColor(lead.status),
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                    DropdownMenu(
                                        expanded = statusMenuExpanded,
                                        onDismissRequest = { statusMenuExpanded = false }
                                    ) {
                                        LeadStatus.entries.forEach { candidate ->
                                            DropdownMenuItem(
                                                text = { Text(candidate.label) },
                                                onClick = {
                                                    onUpdateLeadStatus(lead.id, candidate)
                                                    statusMenuExpanded = false
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddLeadDialog(
            onDismiss = { showAddDialog = false },
            onSave = { name, mobile, email, req, source, status, date ->
                onAddLead(name, mobile, email, req, source, status, date)
                showAddDialog = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddLeadDialog(
    onDismiss: () -> Unit,
    onSave: (String, String, String, String, LeadSource, LeadStatus, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var mobile by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var requirement by remember { mutableStateOf("") }
    var followUpDate by remember { mutableStateOf("2026-11-30") }
    var selectedSource by remember { mutableStateOf(LeadSource.GOOGLE) }
    var selectedStatus by remember { mutableStateOf(LeadStatus.NEW) }
    var errorText by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add New Customer Lead") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it; errorText = null },
                    label = { Text("Customer Name *") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = mobile,
                    onValueChange = { mobile = it; errorText = null },
                    label = { Text("Mobile Number *") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email Address") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = requirement,
                    onValueChange = { requirement = it; errorText = null },
                    label = { Text("Business Requirement *") }
                )
                OutlinedTextField(
                    value = followUpDate,
                    onValueChange = { followUpDate = it },
                    label = { Text("Follow-up Date (YYYY-MM-DD)") },
                    singleLine = true
                )
                Text("Lead Source", style = MaterialTheme.typography.labelMedium)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    LeadSource.entries.forEach { src ->
                        FilterChip(
                            selected = selectedSource == src,
                            onClick = { selectedSource = src },
                            label = { Text(src.label) }
                        )
                    }
                }
                Text("Initial Status", style = MaterialTheme.typography.labelMedium)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    LeadStatus.entries.forEach { st ->
                        FilterChip(
                            selected = selectedStatus == st,
                            onClick = { selectedStatus = st },
                            label = { Text(st.label) }
                        )
                    }
                }
                if (errorText != null) {
                    Text(errorText!!, color = CrimsonAlert, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val cleanDigits = mobile.filter { it.isDigit() }
                    when {
                        name.isBlank() -> errorText = "Customer name is required."
                        cleanDigits.length < 10 -> errorText = "Enter a valid 10-digit mobile number."
                        requirement.isBlank() -> errorText = "Please describe the business requirement."
                        else -> onSave(name, cleanDigits, email, requirement, selectedSource, selectedStatus, followUpDate)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = TealAccent)
            ) {
                Text("Save Lead")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
