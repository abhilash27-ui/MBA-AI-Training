package com.bizgrow.app.model

enum class LeadSource(val label: String) {
    GOOGLE("Google"),
    INSTAGRAM("Instagram"),
    FACEBOOK("Facebook"),
    REFERRAL("Referral"),
    WALK_IN("Walk-in")
}

enum class LeadStatus(val label: String) {
    NEW("New"),
    CONTACTED("Contacted"),
    INTERESTED("Interested"),
    CONVERTED("Converted"),
    LOST("Lost")
}

enum class ActivityStatus(val label: String) {
    PENDING("Pending"),
    IN_PROGRESS("In Progress"),
    COMPLETED("Completed")
}

enum class PriorityLevel(val label: String) {
    HIGH("High"),
    MEDIUM("Medium"),
    LOW("Low")
}

data class CustomerLead(
    val id: String,
    val customerName: String,
    val mobileNumber: String,
    val email: String,
    val businessRequirement: String,
    val source: LeadSource,
    val status: LeadStatus,
    val followUpDate: String,
    val isSample: Boolean = false
)

data class MarketingActivity(
    val id: String,
    val name: String,
    val description: String,
    val status: ActivityStatus,
    val budgetInr: Double,
    val targetAudience: String,
    val expectedOutcome: String,
    val isSample: Boolean = false
)

data class BusinessRecommendation(
    val id: String,
    val title: String,
    val explanation: String,
    val priority: PriorityLevel,
    val suggestedAction: String,
    val expectedBenefit: String,
    val isSample: Boolean = true
)

data class BusinessProfile(
    val businessName: String,
    val category: String,
    val location: String,
    val ownerName: String,
    val email: String,
    val isDemoUser: Boolean
)

data class MonthlySampleBenchmark(
    val totalEnquiries: Int = 120,
    val newLeads: Int = 35,
    val convertedCustomers: Int = 28,
    val conversionRatePercent: Double = 23.3,
    val marketingBudgetInr: Double = 15000.0,
    val estimatedRevenueInr: Double = 85000.0,
    val googleEnquiries: Int = 40,
    val instagramEnquiries: Int = 35,
    val facebookEnquiries: Int = 25,
    val referralEnquiries: Int = 20
)
