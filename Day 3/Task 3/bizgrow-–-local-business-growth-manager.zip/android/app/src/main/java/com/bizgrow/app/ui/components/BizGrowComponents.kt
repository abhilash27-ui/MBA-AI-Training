package com.bizgrow.app.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.bizgrow.app.model.*
import com.bizgrow.app.ui.theme.*
import java.text.NumberFormat
import java.util.Locale

fun formatInr(amount: Double): String {
    val formatter = NumberFormat.getNumberInstance(Locale("en", "IN"))
    formatter.maximumFractionDigits = 0
    return "₹${formatter.format(amount.toLong())}"
}

@Composable
fun BizGrowMetricCard(
    title: String,
    value: String,
    subtitle: String,
    accentColor: Color = NavyPrimary,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = SurfaceCard,
        border = BorderStroke(1.dp, BorderHairline),
        shadowElevation = 1.dp
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium,
                color = TextMuted
            )
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = accentColor
                )
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted
            )
        }
    }
}

@Composable
fun SectionHeader(
    title: String,
    subtitle: String? = null,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            color = TextPrimary
        )
        if (!subtitle.isNullOrBlank()) {
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = TextMuted
            )
        }
    }
}

@Composable
fun SampleOrUserLabel(isSample: Boolean) {
    Text(
        text = if (isSample) "Sample Data" else "User Added",
        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
        color = if (isSample) TextMuted else TealAccent
    )
}

fun leadStatusColor(status: LeadStatus): Color = when (status) {
    LeadStatus.NEW -> NavySecondary
    LeadStatus.CONTACTED -> Color(0xFF0284C7)
    LeadStatus.INTERESTED -> AmberWarning
    LeadStatus.CONVERTED -> EmeraldSuccess
    LeadStatus.LOST -> CrimsonAlert
}

fun activityStatusColor(status: ActivityStatus): Color = when (status) {
    ActivityStatus.PENDING -> AmberWarning
    ActivityStatus.IN_PROGRESS -> Color(0xFF0284C7)
    ActivityStatus.COMPLETED -> EmeraldSuccess
}

fun priorityColor(priority: PriorityLevel): Color = when (priority) {
    PriorityLevel.HIGH -> CrimsonAlert
    PriorityLevel.MEDIUM -> AmberWarning
    PriorityLevel.LOW -> TealAccent
}

@Composable
fun EmptyStateCard(
    title: String,
    message: String,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = SurfaceCard,
        border = BorderStroke(1.dp, BorderHairline)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(message, style = MaterialTheme.typography.bodySmall, color = TextMuted)
            if (actionLabel != null && onAction != null) {
                Spacer(modifier = Modifier.height(4.dp))
                Button(
                    onClick = onAction,
                    colors = ButtonDefaults.buttonColors(containerColor = TealAccent)
                ) {
                    Text(actionLabel)
                }
            }
        }
    }
}
