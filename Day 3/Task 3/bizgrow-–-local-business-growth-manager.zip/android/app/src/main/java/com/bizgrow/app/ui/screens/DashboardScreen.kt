package com.bizgrow.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.bizgrow.app.ui.components.*
import com.bizgrow.app.ui.navigation.BizGrowRoute
import com.bizgrow.app.ui.theme.*
import com.bizgrow.app.viewmodel.BizGrowUiState
import java.util.Locale

@Composable
fun DashboardScreen(
    state: BizGrowUiState,
    onNavigate: (BizGrowRoute) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = NavyPrimary,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Welcome back, ${state.profile.ownerName}",
                        style = MaterialTheme.typography.labelMedium,
                        color = Color(0xFF94A3B8)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = state.profile.businessName,
                        style = MaterialTheme.typography.titleLarge.copy(
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = "${state.profile.category} · ${state.profile.location}",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFCBD5E1)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Live pipeline figures update automatically from your Leads & Marketing tabs. Sample baseline records are clearly marked.",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFF5EEAD4)
                    )
                }
            }
        }

        item {
            SectionHeader(
                title = "Live Business Overview",
                subtitle = "Calculated from ${state.totalLeads} tracked leads & ${state.activities.size} activities"
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                BizGrowMetricCard(
                    title = "Total Enquiries",
                    value = state.totalLeads.toString(),
                    subtitle = "${state.leads.count { !it.isSample }} user added · ${state.leads.count { it.isSample }} sample",
                    modifier = Modifier.weight(1f)
                )
                BizGrowMetricCard(
                    title = "New Leads",
                    value = state.newLeadsCount.toString(),
                    subtitle = "Awaiting first response",
                    accentColor = NavySecondary,
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                BizGrowMetricCard(
                    title = "Converted Customers",
                    value = state.convertedLeadsCount.toString(),
                    subtitle = "${state.interestedLeadsCount} interested in pipeline",
                    accentColor = EmeraldSuccess,
                    modifier = Modifier.weight(1f)
                )
                BizGrowMetricCard(
                    title = "Conversion Rate",
                    value = String.format(Locale.US, "%.1f%%", state.conversionRatePercent),
                    subtitle = "(Converted / Total) × 100",
                    accentColor = TealAccent,
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                BizGrowMetricCard(
                    title = "Monthly Marketing Spend",
                    value = formatInr(state.totalMarketingExpenditureInr),
                    subtitle = "Sum of active budgets",
                    accentColor = NavyPrimary,
                    modifier = Modifier.weight(1f)
                )
                BizGrowMetricCard(
                    title = "Estimated Revenue",
                    value = formatInr(state.estimatedRevenueInr),
                    subtitle = "Includes sample demo baseline",
                    accentColor = TealAccent,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFFF1F5F9),
                border = BorderStroke(1.dp, BorderHairline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Monthly Demo Benchmark (Sample Data)",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = NavyPrimary
                    )
                    Text(
                        text = "${state.sampleBenchmark.totalEnquiries} Enquiries · ${state.sampleBenchmark.newLeads} New · ${state.sampleBenchmark.convertedCustomers} Converted (${state.sampleBenchmark.conversionRatePercent}%) · Budget ${formatInr(state.sampleBenchmark.marketingBudgetInr)} · Est. Revenue ${formatInr(state.sampleBenchmark.estimatedRevenueInr)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )
                }
            }
        }

        item {
            SectionHeader(
                title = "Quick Navigation",
                subtitle = "Jump directly to any growth module"
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { onNavigate(BizGrowRoute.LEADS) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                ) { Text("Manage Leads") }
                OutlinedButton(
                    onClick = { onNavigate(BizGrowRoute.MARKETING) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                ) { Text("Marketing") }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { onNavigate(BizGrowRoute.REPORTS) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                ) { Text("View Reports") }
                OutlinedButton(
                    onClick = { onNavigate(BizGrowRoute.RECOMMENDATIONS) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                ) { Text("Recommendations") }
            }
        }

        item {
            SectionHeader(
                title = "Recent Customer Enquiries",
                subtitle = "Latest leads in your local pipeline"
            )
        }

        items(state.leads.take(4), key = { it.id }) { lead ->
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = SurfaceCard,
                border = BorderStroke(1.dp, BorderHairline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(lead.customerName, style = MaterialTheme.typography.titleSmall)
                        Text(
                            text = "${lead.source.label} · Follow-up ${lead.followUpDate}",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextMuted
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = lead.status.label,
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = leadStatusColor(lead.status)
                        )
                        SampleOrUserLabel(isSample = lead.isSample)
                    }
                }
            }
        }

        item {
            val completedCount = state.activities.count { it.status == com.bizgrow.app.model.ActivityStatus.COMPLETED }
            val inProgressCount = state.activities.count { it.status == com.bizgrow.app.model.ActivityStatus.IN_PROGRESS }
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = SurfaceCard,
                border = BorderStroke(1.dp, BorderHairline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Marketing Performance Summary", style = MaterialTheme.typography.titleMedium)
                    Text(
                        text = "$completedCount completed · $inProgressCount in progress · Total budget ${formatInr(state.totalMarketingExpenditureInr)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )
                }
            }
        }
    }
}
