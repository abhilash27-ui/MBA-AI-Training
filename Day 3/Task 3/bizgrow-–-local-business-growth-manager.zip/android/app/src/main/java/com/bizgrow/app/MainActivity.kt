package com.bizgrow.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.bizgrow.app.ui.navigation.BizGrowApp
import com.bizgrow.app.ui.theme.BizGrowTheme
import com.bizgrow.app.viewmodel.BizGrowViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            BizGrowTheme {
                val bizGrowViewModel: BizGrowViewModel = viewModel()
                BizGrowApp(viewModel = bizGrowViewModel)
            }
        }
    }
}
