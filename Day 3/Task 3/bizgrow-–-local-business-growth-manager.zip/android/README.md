# BizGrow – Native Android Application (Kotlin + Jetpack Compose + Material 3)

## Architecture
- **Language**: Kotlin
- **UI**: Jetpack Compose + Material 3
- **Architecture**: MVVM (`BizGrowViewModel` + `StateFlow`)
- **Navigation**: Jetpack Compose Navigation (`NavHost` + Material 3 `NavigationBar`)
- **Local Persistence**: `SharedPreferences` + `org.json` (`BizGrowLocalStore`)

## Six Screens Included
1. `WelcomeLoginScreen.kt` – Sign in, Register, or Continue as Demo User
2. `DashboardScreen.kt` – Live business overview & sample monthly benchmark for Sharma Digital Services (Nagpur)
3. `LeadsScreen.kt` – Search, filter, add validated leads, update status
4. `MarketingScreen.kt` – Monitor channels, add activities, track total ₹ expenditure
5. `ReportsScreen.kt` – Lead conversion analytics & channel breakdown
6. `RecommendationsScreen.kt` – Predefined local growth action cards

## How to Build APK in Android Studio
1. Extract this ZIP and open the `android/` folder in **Android Studio (Ladybug or newer)**.
2. Allow Gradle to sync dependencies (`JDK 17`, Android `compileSdk 35`).
3. Click **Run** to launch on an Android Emulator (Pixel 7 / API 34+), or **Build > Build Bundle(s) / APK(s) > Build APK(s)** to generate the `.apk`.
